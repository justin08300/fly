import { contextBridge } from 'electron';

// Minimal, read-only bridge. The renderer never gets Node access.
contextBridge.exposeInMainWorld('neonVoid', {
  isElectron: true,
  platform: process.platform,
});
