import { app, BrowserWindow, Menu, net, protocol } from 'electron';
import fs from 'node:fs/promises';
import path from 'node:path';

/**
 * Asset strategy
 * --------------
 *  DEV         renderer is served by Vite (http://localhost:5173); Vite serves ./data and ./pdoom.mp3.
 *  PRODUCTION  renderer is loaded from the custom `neon://app/` protocol:
 *                neon://app/index.html, /assets/*  -> <app.asar>/dist/*
 *                neon://app/pdoom.mp3, /data/*.json -> assetRoot()
 *              assetRoot() = process.resourcesPath when packaged (electron-builder extraResources),
 *                            or the project folder when running `npm run electron` unpackaged.
 *  Nothing depends on a hard-coded user path.
 */
const isDev = process.env.NEON_DEV === '1';
const DEV_URL = 'http://localhost:5173';
const SCHEME = 'neon';

protocol.registerSchemesAsPrivileged([
  {
    scheme: SCHEME,
    privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true },
  },
]);

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.mp3': 'audio/mpeg',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.map': 'application/json',
};

function assetRoot(): string {
  return app.isPackaged ? process.resourcesPath : app.getAppPath();
}
function distRoot(): string {
  return path.join(app.getAppPath(), 'dist');
}

function isAssetRequest(p: string): boolean {
  return p === '/pdoom.mp3' || /^\/data\/[\w.-]+\.json$/.test(p);
}

function registerNeonProtocol(): void {
  protocol.handle(SCHEME, async (request) => {
    try {
      const url = new URL(request.url);
      let pathname = decodeURIComponent(url.pathname);
      if (pathname === '/' || pathname === '') pathname = '/index.html';

      const base = isAssetRequest(pathname) ? assetRoot() : distRoot();
      const file = path.normalize(path.join(base, pathname));
      // Path traversal guard.
      if (!file.startsWith(path.normalize(base + path.sep))) {
        return new Response('forbidden', { status: 403 });
      }
      const buf = await fs.readFile(file); // asar-aware in Electron
      return new Response(buf, {
        status: 200,
        headers: {
          'Content-Type': MIME[path.extname(file).toLowerCase()] ?? 'application/octet-stream',
          'Content-Length': String(buf.length),
          'Cache-Control': 'no-cache',
        },
      });
    } catch {
      return new Response('not found', { status: 404 });
    }
  });
  void net; // (kept for future network-backed assets)
}

function createWindow(): void {
  const win = new BrowserWindow({
    width: 1600,
    height: 900,
    minWidth: 800,
    minHeight: 450,
    backgroundColor: '#000000',
    title: 'NEON // VOID',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });

  win.once('ready-to-show', () => win.show());
  win.webContents.on('did-fail-load', (_e, code, desc, url) => {
    const html = `<body style="background:#000;color:#00f0ff;font:16px 'Segoe UI',sans-serif;display:grid;place-items:center;height:100vh;margin:0;text-align:center">
      <div><div style="letter-spacing:.4em;font-size:22px">NEON // VOID</div><p style="opacity:.7">Failed to load the application (${desc}).</p><p style="opacity:.4;font-size:12px">${url} · ${code}</p></div></body>`;
    void win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  });

  void win.loadURL(isDev ? DEV_URL : `${SCHEME}://app/index.html`);
}

app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('disable-renderer-backgrounding');

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  if (!isDev) registerNeonProtocol();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
