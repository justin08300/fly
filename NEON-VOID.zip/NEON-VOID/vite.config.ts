import { defineConfig, type Plugin } from 'vite';
import fs from 'node:fs';
import path from 'node:path';

/**
 * In development / preview the music + analysis data live in the project root
 * (./pdoom.mp3 and ./data/*). This tiny plugin serves them at the same URLs the
 * Electron `neon://` protocol serves in production, so the renderer code never
 * has to care where it is running.
 */
function neonAssets(): Plugin {
  const root = process.cwd();
  const mime: Record<string, string> = {
    '.json': 'application/json',
    '.mp3': 'audio/mpeg',
  };
  const handler = (req: any, res: any, next: () => void) => {
    const url = decodeURIComponent((req.url ?? '').split('?')[0]);
    if (url !== '/pdoom.mp3' && !/^\/data\/[\w.-]+\.json$/.test(url)) return next();
    const file = path.join(root, url);
    if (!fs.existsSync(file)) {
      res.statusCode = 404;
      return res.end('not found');
    }
    const stat = fs.statSync(file);
    res.setHeader('Content-Type', mime[path.extname(file)] ?? 'application/octet-stream');
    res.setHeader('Content-Length', stat.size);
    res.setHeader('Cache-Control', 'no-cache');
    fs.createReadStream(file).pipe(res);
  };
  return {
    name: 'neon-assets',
    configureServer: (s) => void s.middlewares.use(handler),
    configurePreviewServer: (s) => void s.middlewares.use(handler),
  };
}

export default defineConfig({
  base: './',
  plugins: [neonAssets()],
  server: { port: 5173, strictPort: true },
  build: {
    outDir: 'dist',
    target: 'es2022',
    chunkSizeWarningLimit: 1500,
  },
});
