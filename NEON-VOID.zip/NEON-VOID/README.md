# NEON // VOID

A music-driven 3D digital universe. TypeScript · Vite · Three.js (WebGL) · Electron · electron-builder.

Everything you see is computed from the song's own analysis data — beats, bass, kicks, snares, vocals, sections and the word-level lyric timeline. Nothing is hard-coded to seconds.

```
black → one point of light → the world is built → bass makes it breathe → lyrics float in 3D
      → the chorus detonates into particles, light and geometry → everything is pulled into the Void → NEON // VOID
```

## Requirements

* **Node.js 20 or newer** (22 LTS recommended) and **npm**
* A GPU with WebGL2 (any integrated GPU from the last ~8 years works; use `1` = LOW on weak machines)
* For the Windows EXE: build on **Windows 10/11 x64**

## Development

```bash
npm install
npm run dev
```

`npm run dev` starts Vite and opens the app in an Electron window with live reload.
To use a normal browser instead: `npm run dev:web` and open http://localhost:5173.

## Build

```bash
npm run build      # type-check + Vite bundle (dist/) + Electron main/preload (dist-electron/)
npm run electron   # build, then run the production build in Electron
npm run preview    # serve dist/ in a browser (Vite preview)
```

## Windows EXE

```bash
npm install
npm run dist
```

Output is written to **`release/`** (inside the project folder):

| File | What it is |
| --- | --- |
| `release/NEON-VOID-Setup-1.0.0.exe` | NSIS installer (choose the install folder, desktop/start-menu shortcut) |
| `release/NEON-VOID-Portable-1.0.0.exe` | Portable single EXE — no installation |
| `release/win-unpacked/NEON-VOID.exe` | Unpacked app folder (`npm run dist:dir` builds only this) |

The music and the JSON data are bundled **inside the installed app** (`resources/pdoom.mp3`, `resources/data/*.json`); users do not need to copy anything anywhere.

## Controls

| Key | Action |
| --- | --- |
| `SPACE` | Play / Pause (the first Play runs a 3.6 s silent intro: light-point → logo → music starts) |
| `←` `→` | Seek −5 s / +5 s |
| `↑` `↓` | Volume |
| `F` | Fullscreen (UI + cursor hide; move the mouse to reveal) |
| `ESC` | Exit fullscreen |
| `1` `2` `3` `4` | Quality LOW / MEDIUM / HIGH / ULTRA |
| `R` | Reset the current scene |

You can also click the progress bar to seek and click QUALITY to cycle presets.

## Data format (verified against the supplied files)

**`data/audio.json`** — all times in seconds on the gapless-MP3 timeline.
`duration`, `bpm`, `beat_period`, `time_signature`, `beats[]`, `downbeats[]`, `sections[{name,start,end}]`,
`fps` (=100) with 100 Hz envelopes `rms low mid high vocal drums bass other` (each 0..1), and
`onsets.{kick,snare,hat,vocal}` as `[time, strength]` pairs.

**`data/lyrics.json`** — `lines[{i,text,start,end,words[{w,start,end,conf,syl?}]}]` (word-level timing) and `extras[{start,end,desc}]` (ad-lib regions).

The parsers (`src/engine/DataLoader.ts`) validate these and show a clear message if something is wrong
(missing `audio.json` → readable error; missing `lyrics.json` → the show runs without lyrics; missing `pdoom.mp3` → "Audio file not found.").
Replace the three files with another song's data of the same shape and the show follows it — scenes are mapped by section name, with a fallback rotation for unknown names.

## Architecture

```
electron/        main.ts (neon:// protocol, asset paths) · preload.ts
src/
  main.ts        boot, loading screen, error screens
  engine/        AudioEngine (audio.currentTime is THE clock) · Timeline (clock → audio.json/lyrics.json)
                 BeatSystem (beat/downbeat/kick/snare/hat/vocal/section/lyric/word events)
                 SceneManager (section → world) · PerformanceManager (LOW…ULTRA, FPS, dynamic resolution)
                 Engine (renderer + the single render loop) · DataLoader · FrameState
  scenes/        Intro · Void · NeonGrid · ParticleStorm · CyberCity · Glitch · EnergyCore · Final
  particles/     ParticleSystem — GPU, analytic motion (dust / tunnel-vortex / burst / sink) + motion trails
  lyrics/        TextParticles (text → particles, form/glow/dissolve in the shader) · LyricsRenderer (3D, follows camera with lag)
  effects/       PostFX (bloom + one uber pass: chromatic aberration, distortion, glitch, scanlines, grain,
                 vignette, grade, flash, radial blur, shockwave) · Shockwave · Materials · Glow
  camera/        CameraController (smoothing, bass FOV, kick shake, parallax, transition whip)
  ui/            UI (HUD + keyboard) · ui.css
```

### Scene plan

| Section(s) | World |
| --- | --- |
| intro | INTRO — light point, particles form the logo |
| verse1, pre3 | DIGITAL VOID — giant breathing rings, monoliths, light shafts, dust |
| pre1, pre2 | NEON GRID — one cell per half-beat, bass terrain, beat ripples, pillars, holo panels |
| chorus1, chorus3 | PARTICLE STORM — tunnel → vortex → implosion → explosion, one regime per bar |
| verse2, bridge | CYBER CITY — procedural towers with beat-flashing windows, neon road, traffic |
| break1, verse3 | GLITCH DIMENSION — stuttering shards, tearing display, RGB split |
| chorus2, chorus4 | ENERGY CORE — plasma core sized by bass, shockwaves, lit rings, orbiting debris |
| outro | FINAL — grid collapses, towers vanish, everything spirals into the Void, light dies, logo |

Scene cuts are made ~50 ms *before* each section boundary so the flash lands exactly on the downbeat.

### Performance

`PerformanceManager` presets control particle count, trails, bloom, post-processing, instance counts, lyric density and real lights.
Dynamic resolution: FPS < 45 → render scale −0.1 (min 0.6, at most every 2 s); FPS > 57 → +0.05 (at most every 6 s).
If it is stuck at the minimum scale and still < 36 FPS, the quality tier drops automatically (unless you chose one manually).

## How assets are found (dev vs. packaged)

* **Dev:** Vite serves `./pdoom.mp3` and `./data/*.json` (see `vite.config.ts`).
* **Packaged:** Electron registers a `neon://app/` protocol (`electron/main.ts`).
  App code is read from `app.asar/dist`; `pdoom.mp3` and `data/*.json` are `extraResources`
  and read from `process.resourcesPath`. When running unpackaged (`npm run electron`) they are read from the project folder.
* The renderer always asks for the relative URLs `pdoom.mp3` and `data/audio.json`, so it never needs to know which mode it is in.

## Notes

* The music is fetched once and played from a Blob URL, so seeking is exact and independent of the protocol.
* audio.json has no separate "bass hit" events (bass exists only as a continuous envelope), so there is no `onBass` event; bass drives visuals continuously via `FrameState.bass / bassS`.
* Debug: `window.__NEON__` exposes the engine in DevTools (Ctrl+Shift+I in dev).
