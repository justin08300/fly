import type { AudioData, EnvName, LyricsData, OnsetName, Section } from '../types';
import { damp, floorIndex, mod } from '../util/math';
import { FrameState } from './FrameState';

const ONSET_TAU: Record<OnsetName, number> = { kick: 0.16, snare: 0.2, hat: 0.07, vocal: 0.22 };

/** Maps the audio clock onto audio.json + lyrics.json. Pure functions of time => seek-safe. */
export class Timeline {
  readonly frame = new FrameState();
  readonly duration: number;
  /** Flattened, time-sorted word starts for event dispatch. */
  readonly wordStarts: { t: number; line: number; word: number }[] = [];
  private firstDownbeatBeat: number;

  constructor(
    readonly audio: AudioData,
    readonly lyrics: LyricsData | null,
  ) {
    this.duration = audio.duration;
    const db0 = audio.downbeats[0] ?? audio.beats[0];
    let best = 0;
    for (let i = 0; i < audio.beats.length; i++) if (Math.abs(audio.beats[i] - db0) < Math.abs(audio.beats[best] - db0)) best = i;
    this.firstDownbeatBeat = best;
    lyrics?.lines.forEach((l, li) => l.words.forEach((w, wi) => this.wordStarts.push({ t: w.start, line: li, word: wi })));
    this.wordStarts.sort((a, b) => a.t - b.t);
  }

  /** Linear-interpolated envelope sample (0 outside the data). */
  sample(name: EnvName, t: number): number {
    const a = this.audio.env[name];
    if (!a.length) return 0;
    const x = t * this.audio.fps;
    if (x <= 0) return a[0];
    const i = Math.floor(x);
    if (i >= a.length - 1) return a[a.length - 1];
    const f = x - i;
    return a[i] * (1 - f) + a[i + 1] * f;
  }

  /** Exponentially decaying "hit" envelope built from the onset list (1 at the hit). */
  onsetEnv(name: OnsetName, t: number): number {
    const o = this.audio.onsets[name];
    const i = floorIndex(o.times, t);
    if (i < 0) return 0;
    const tau = ONSET_TAU[name];
    let v = o.strengths[i] * Math.exp(-(t - o.times[i]) / tau);
    if (i > 0) v = Math.max(v, o.strengths[i - 1] * Math.exp(-(t - o.times[i - 1]) / tau));
    return v;
  }

  sectionIndexAt(t: number): number {
    const s = this.audio.sections;
    for (let i = s.length - 1; i >= 0; i--) if (t >= s[i].start) return i;
    return 0;
  }

  lineIndexAt(t: number): number {
    if (!this.lyrics) return -1;
    const L = this.lyrics.lines;
    let ans = -1;
    for (let i = 0; i < L.length; i++) {
      if (L[i].start <= t) ans = i;
      else break;
    }
    return ans !== -1 && t < L[ans].end + 0.4 ? ans : -1;
  }

  update(t: number, dt: number, real: number, playing: boolean, pre: number): FrameState {
    const f = this.frame;
    const A = this.audio;
    f.t = t;
    f.dt = dt;
    f.real = real;
    f.playing = playing;
    f.pre = pre;
    f.bpm = A.bpm;
    f.beatPeriod = A.beatPeriod;

    // --- beats / bars --------------------------------------------------------------------
    const bi = floorIndex(A.beats, t);
    let beatPos: number;
    if (bi < 0) beatPos = (t - A.beats[0]) / A.beatPeriod;
    else {
      const next = A.beats[bi + 1] ?? A.beats[bi] + A.beatPeriod;
      beatPos = bi + (t - A.beats[bi]) / (next - A.beats[bi]);
    }
    f.beatPos = beatPos;
    f.beatIndex = Math.floor(beatPos);
    f.beatPhase = beatPos - f.beatIndex;
    f.sinceBeat = f.beatPhase * A.beatPeriod;
    const ts = A.timeSignature;
    const relBeat = f.beatIndex - this.firstDownbeatBeat;
    f.beatInBar = mod(relBeat, ts);
    f.barIndex = Math.floor(relBeat / ts);
    f.barPhase = (f.beatInBar + f.beatPhase) / ts;
    f.sinceDownbeat = (f.beatInBar + f.beatPhase) * A.beatPeriod;

    // --- sections ------------------------------------------------------------------------
    const si = this.sectionIndexAt(t);
    const sec: Section = A.sections[si];
    f.sectionIndex = si;
    f.section = sec;
    f.sectionName = sec.name;
    f.sectionTime = Math.max(0, t - sec.start);
    f.sectionProgress = Math.min(1, Math.max(0, (t - sec.start) / Math.max(1e-3, sec.end - sec.start)));
    f.barInSection = Math.floor(f.sectionTime / (A.beatPeriod * ts));

    // --- continuous envelopes ------------------------------------------------------------
    f.rms = this.sample('rms', t);
    f.low = this.sample('low', t);
    f.mid = this.sample('mid', t);
    f.high = this.sample('high', t);
    f.vocal = this.sample('vocal', t);
    f.drums = this.sample('drums', t);
    f.bass = this.sample('bass', t);
    f.other = this.sample('other', t);
    const d = Math.min(dt, 0.1);
    f.energy = damp(f.energy, f.rms, 2.5, d);
    f.bassS = damp(f.bassS, Math.max(f.bass, f.low * 0.8), 9, d);

    // --- hits ----------------------------------------------------------------------------
    f.kick = this.onsetEnv('kick', t);
    f.snare = this.onsetEnv('snare', t);
    f.hat = this.onsetEnv('hat', t);
    f.vocalHit = this.onsetEnv('vocal', t);

    // --- lyrics --------------------------------------------------------------------------
    f.lineIndex = this.lineIndexAt(t);
    f.wordIndex = -1;
    if (f.lineIndex >= 0 && this.lyrics) {
      const ws = this.lyrics.lines[f.lineIndex].words;
      for (let i = 0; i < ws.length; i++) if (ws[i].start <= t) f.wordIndex = i;
    }
    f.extraActive = !!this.lyrics?.extras.some((e) => t >= e.start && t <= e.end);
    return f;
  }

  // Convenience accessors (the API requested in the brief) -------------------------------
  getCurrentBeat() {
    return { index: this.frame.beatIndex, phase: this.frame.beatPhase, inBar: this.frame.beatInBar };
  }
  getCurrentSection() {
    return this.frame.section;
  }
  getCurrentLyric() {
    const f = this.frame;
    return f.lineIndex >= 0 && this.lyrics ? this.lyrics.lines[f.lineIndex] : null;
  }
  getBass() {
    return this.frame.bass;
  }
  getRMS() {
    return this.frame.rms;
  }
}
