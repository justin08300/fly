import type { LyricLine, OnsetName, Section } from '../types';
import { floorIndex } from '../util/math';
import type { Timeline } from './Timeline';

export interface BeatEvent { index: number; time: number; beatInBar: number; downbeat: boolean }
export interface OnsetEvent { time: number; strength: number }
export interface SectionEvent { from: Section | null; to: Section; index: number }
export interface LineEvent { line: LyricLine; index: number }
export interface WordEvent { line: LyricLine; lineIndex: number; wordIndex: number }

export interface EventMap {
  beat: BeatEvent;
  downbeat: BeatEvent;
  kick: OnsetEvent;
  snare: OnsetEvent;
  hat: OnsetEvent;
  vocal: OnsetEvent;
  sectionChange: SectionEvent;
  lyricStart: LineEvent;
  lyricEnd: LineEvent;
  wordStart: WordEvent;
  /** The playhead jumped (seek / resume). Listeners should re-sync, not animate. */
  seek: { t: number };
}
export type EventType = keyof EventMap;

/**
 * Fires discrete events for everything that happened in (previous time, current time].
 * There is no bass event: audio.json carries bass only as a continuous envelope, so it is
 * exposed through Timeline / FrameState instead of an invented trigger.
 */
export class BeatSystem {
  private handlers = new Map<EventType, Set<(e: any) => void>>();
  private last = -1;
  private lastSection = -1;

  constructor(private tl: Timeline) {}

  on<K extends EventType>(type: K, cb: (e: EventMap[K]) => void): () => void {
    let set = this.handlers.get(type);
    if (!set) this.handlers.set(type, (set = new Set()));
    set.add(cb);
    return () => set!.delete(cb);
  }

  private emit<K extends EventType>(type: K, e: EventMap[K]) {
    this.handlers.get(type)?.forEach((cb) => cb(e));
  }

  /** Forget history (use after seek / restart). */
  reset() {
    this.last = -1;
  }

  update(t: number) {
    const A = this.tl.audio;
    const si = this.tl.frame.sectionIndex;
    const jumped = this.last < 0 || t < this.last || t - this.last > 0.35;
    if (jumped) {
      this.last = t;
      this.lastSection = si;
      this.emit('seek', { t });
      return;
    }
    const a = this.last;
    this.last = t;

    // beats & downbeats
    for (let i = floorIndex(A.beats, a) + 1; i < A.beats.length && A.beats[i] <= t; i++) {
      const time = A.beats[i];
      const isDown = floorIndex(A.downbeats, time + 1e-3) >= 0 && Math.abs(A.downbeats[floorIndex(A.downbeats, time + 1e-3)] - time) < 0.01;
      const ev: BeatEvent = { index: i, time, beatInBar: isDown ? 0 : -1, downbeat: isDown };
      this.emit('beat', ev);
      if (isDown) this.emit('downbeat', ev);
    }
    // percussive / vocal onsets
    (['kick', 'snare', 'hat', 'vocal'] as OnsetName[]).forEach((name) => {
      const o = A.onsets[name];
      for (let i = floorIndex(o.times, a) + 1; i < o.times.length && o.times[i] <= t; i++) {
        this.emit(name, { time: o.times[i], strength: o.strengths[i] });
      }
    });
    // sections
    if (si !== this.lastSection) {
      this.emit('sectionChange', { from: A.sections[this.lastSection] ?? null, to: A.sections[si], index: si });
      this.lastSection = si;
    }
    // lyrics
    const L = this.tl.lyrics;
    if (L) {
      L.lines.forEach((line, index) => {
        if (line.start > a && line.start <= t) this.emit('lyricStart', { line, index });
        if (line.end > a && line.end <= t) this.emit('lyricEnd', { line, index });
      });
      for (const w of this.tl.wordStarts) {
        if (w.t > a && w.t <= t) this.emit('wordStart', { line: L.lines[w.line], lineIndex: w.line, wordIndex: w.word });
      }
    }
  }
}
