import type { QualitySettings } from '../types';
import { clamp } from '../util/math';

export type QualityName = QualitySettings['name'];

export const QUALITY: Record<QualityName, QualitySettings> = {
  LOW: {
    name: 'LOW', pixelRatioCap: 0.75, particleScale: 0.3, trails: 0, bloom: false, bloomStrength: 0, bloomRadius: 0.3,
    bloomResolution: 0.5, post: 0.25, instanceScale: 0.4, lyricDensity: 0.45, dynamicLights: false,
  },
  MEDIUM: {
    name: 'MEDIUM', pixelRatioCap: 1, particleScale: 0.6, trails: 0, bloom: true, bloomStrength: 0.45, bloomRadius: 0.5,
    bloomResolution: 0.4, post: 0.6, instanceScale: 0.7, lyricDensity: 0.75, dynamicLights: false,
  },
  HIGH: {
    name: 'HIGH', pixelRatioCap: 1.5, particleScale: 1, trails: 1, bloom: true, bloomStrength: 0.6, bloomRadius: 0.65,
    bloomResolution: 0.5, post: 1, instanceScale: 1, lyricDensity: 1, dynamicLights: true,
  },
  ULTRA: {
    name: 'ULTRA', pixelRatioCap: 2, particleScale: 1.7, trails: 3, bloom: true, bloomStrength: 0.75, bloomRadius: 0.8,
    bloomResolution: 0.65, post: 1, instanceScale: 1.5, lyricDensity: 1, dynamicLights: true,
  },
};
const ORDER: QualityName[] = ['LOW', 'MEDIUM', 'HIGH', 'ULTRA'];

/**
 * Quality presets, FPS monitor and dynamic resolution.
 *  - FPS < 45  -> lower render resolution one 0.1 step (at most once per 2 s)
 *  - FPS > 57  -> raise it by 0.05 (at most once per 6 s) so it never oscillates
 *  - stuck at the resolution floor and still < 36 FPS -> step the quality tier down
 *    (only if the user never chose a tier manually)
 */
export class PerformanceManager {
  settings: QualitySettings = QUALITY.HIGH;
  fps = 60;
  resolutionScale = 1;
  readonly minScale = 0.6;
  onChange: (reason: 'quality' | 'resolution') => void = () => {};

  private manual = false;
  private acc = 0;
  private frames = 0;
  private sinceChange = 0;
  private warm = 2.5;
  private lowStreak = 0;

  constructor(initial: QualityName = 'HIGH') {
    this.settings = QUALITY[initial];
  }

  get quality(): QualityName {
    return this.settings.name;
  }

  setQuality(name: QualityName, manual = true) {
    if (manual) this.manual = true;
    this.settings = QUALITY[name];
    this.resolutionScale = 1;
    this.sinceChange = 0;
    this.warm = 1.5;
    this.lowStreak = 0;
    this.onChange('quality');
  }

  cycle() {
    this.setQuality(ORDER[(ORDER.indexOf(this.settings.name) + 1) % ORDER.length]);
  }

  pixelRatio(): number {
    return Math.max(0.4, Math.min(window.devicePixelRatio || 1, this.settings.pixelRatioCap) * this.resolutionScale);
  }

  /** Call once per rendered frame (dt in seconds). */
  tick(dt: number, active: boolean) {
    if (!active) return; // hidden tab / paused states shouldn't poison the average
    this.acc += dt;
    this.frames++;
    this.sinceChange += dt;
    this.warm -= dt;
    if (this.acc < 0.5) return;
    this.fps = this.frames / this.acc;
    this.acc = 0;
    this.frames = 0;
    if (this.warm > 0) return;

    if (this.fps < 45 && this.sinceChange > 2) {
      if (this.resolutionScale > this.minScale + 1e-3) {
        this.resolutionScale = clamp(Math.round((this.resolutionScale - 0.1) * 100) / 100, this.minScale, 1);
        this.sinceChange = 0;
        this.onChange('resolution');
      } else if (this.fps < 36 && !this.manual && this.settings.name !== 'LOW') {
        this.lowStreak++;
        if (this.lowStreak >= 4) {
          this.setQuality(ORDER[ORDER.indexOf(this.settings.name) - 1], false);
        }
      }
    } else if (this.fps > 57 && this.sinceChange > 6 && this.resolutionScale < 1) {
      this.resolutionScale = clamp(Math.round((this.resolutionScale + 0.05) * 100) / 100, this.minScale, 1);
      this.sinceChange = 0;
      this.onChange('resolution');
    } else if (this.fps >= 45) this.lowStreak = 0;
  }
}
