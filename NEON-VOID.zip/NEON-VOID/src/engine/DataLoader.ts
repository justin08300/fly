import type { AudioData, EnvName, LyricExtra, LyricLine, LyricsData, OnsetName, OnsetTrack, Section } from '../types';

/** An error whose message is safe and clear enough to show to the user. */
export class DataError extends Error {
  constructor(
    message: string,
    public readonly kind: 'audio-file' | 'audio-json' | 'lyrics-json' | 'webgl' = 'audio-json',
  ) {
    super(message);
  }
}

const ENV_NAMES: EnvName[] = ['rms', 'low', 'mid', 'high', 'vocal', 'drums', 'bass', 'other'];
const ONSET_NAMES: OnsetName[] = ['kick', 'snare', 'hat', 'vocal'];

/** Resolves relative to the page, so it works under Vite (http://) and Electron (neon://). */
export const assetUrl = (name: string) => new URL(name, document.baseURI).toString();

async function fetchJson(rel: string): Promise<unknown> {
  const res = await fetch(assetUrl(rel), { cache: 'no-cache' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

const isNum = (x: unknown): x is number => typeof x === 'number' && Number.isFinite(x);
const isNumArr = (x: unknown): x is number[] => Array.isArray(x) && x.every(isNum);

function need<T>(cond: T | false | undefined | null, msg: string): T {
  if (!cond) throw new DataError(`audio.json: ${msg}`, 'audio-json');
  return cond;
}

export function parseAudio(raw: any): AudioData {
  need(raw && typeof raw === 'object', 'root must be an object');
  const duration = need(isNum(raw.duration) && raw.duration > 0 && raw.duration, '"duration" (seconds) is missing');
  const beats = need(isNumArr(raw.beats) && raw.beats.length > 1 && raw.beats, '"beats" must be a non-empty number array');
  const downbeats = isNumArr(raw.downbeats) && raw.downbeats.length ? raw.downbeats : beats.filter((_: number, i: number) => i % 4 === 0);
  const bpm = isNum(raw.bpm) ? raw.bpm : 60 / ((beats[beats.length - 1] - beats[0]) / (beats.length - 1));
  const beatPeriod = isNum(raw.beat_period) ? raw.beat_period : 60 / bpm;
  const fps = need(isNum(raw.fps) && raw.fps > 0 && raw.fps, '"fps" (envelope sample rate) is missing');

  const sections: Section[] = need(Array.isArray(raw.sections) && raw.sections.length > 0 && raw.sections, '"sections" must be a non-empty array').map(
    (s: any, i: number) => {
      need(s && typeof s.name === 'string' && isNum(s.start) && isNum(s.end), `sections[${i}] needs {name,start,end}`);
      return { name: s.name, start: s.start, end: s.end } as Section;
    },
  );

  const env = {} as Record<EnvName, Float32Array>;
  for (const n of ENV_NAMES) {
    const a = raw[n];
    // Optional channels are allowed to be absent; they read as 0.
    env[n] = isNumArr(a) ? Float32Array.from(a) : new Float32Array(0);
  }
  need(env.rms.length > 0, '"rms" envelope is missing');

  const onsets = {} as Record<OnsetName, OnsetTrack>;
  for (const n of ONSET_NAMES) {
    const list = raw.onsets?.[n];
    const times: number[] = [];
    const strengths: number[] = [];
    if (Array.isArray(list)) {
      for (const p of list) {
        if (Array.isArray(p) && isNum(p[0])) {
          times.push(p[0]);
          strengths.push(isNum(p[1]) ? p[1] : 1);
        }
      }
    }
    onsets[n] = { times: Float64Array.from(times), strengths: Float32Array.from(strengths) };
  }

  return {
    duration,
    bpm,
    beatPeriod,
    timeSignature: isNum(raw.time_signature) ? raw.time_signature : 4,
    beats: Float64Array.from(beats),
    downbeats: Float64Array.from(downbeats),
    sections,
    fps,
    env,
    onsets,
  };
}

export function parseLyrics(raw: any): LyricsData {
  if (!raw || !Array.isArray(raw.lines)) throw new DataError('lyrics.json: "lines" array is missing', 'lyrics-json');
  const lines: LyricLine[] = raw.lines
    .filter((l: any) => l && typeof l.text === 'string' && isNum(l.start) && isNum(l.end))
    .map((l: any, idx: number) => ({
      i: isNum(l.i) ? l.i : idx,
      text: l.text,
      start: l.start,
      end: l.end,
      words:
        Array.isArray(l.words) && l.words.length
          ? l.words
              .filter((w: any) => w && typeof w.w === 'string' && isNum(w.start) && isNum(w.end))
              .map((w: any) => ({ w: w.w, start: w.start, end: w.end, conf: isNum(w.conf) ? w.conf : 1, syl: w.syl }))
          : // Fallback: spread the words evenly over the line if word timing is missing.
            l.text
              .split(/\s+/)
              .filter(Boolean)
              .map((w: string, k: number, arr: string[]) => ({
                w,
                start: l.start + ((l.end - l.start) * k) / arr.length,
                end: l.start + ((l.end - l.start) * (k + 1)) / arr.length,
                conf: 0.5,
              })),
    }))
    .sort((a: LyricLine, b: LyricLine) => a.start - b.start);
  const extras: LyricExtra[] = Array.isArray(raw.extras)
    ? raw.extras.filter((e: any) => e && isNum(e.start) && isNum(e.end)).map((e: any) => ({ start: e.start, end: e.end, desc: String(e.desc ?? '') }))
    : [];
  return { lines, extras };
}

export async function loadAudioJson(): Promise<AudioData> {
  let raw: unknown;
  try {
    raw = await fetchJson('data/audio.json');
  } catch (e) {
    if (e instanceof SyntaxError) throw new DataError('audio.json is not valid JSON.', 'audio-json');
    throw new DataError('audio.json not found.', 'audio-json');
  }
  return parseAudio(raw);
}

/** Lyrics are optional: returns null (never throws) so the show can go on without them. */
export async function loadLyricsJson(): Promise<LyricsData | null> {
  try {
    return parseLyrics(await fetchJson('data/lyrics.json'));
  } catch (e) {
    console.warn('[NEON//VOID] lyrics unavailable:', e);
    return null;
  }
}
