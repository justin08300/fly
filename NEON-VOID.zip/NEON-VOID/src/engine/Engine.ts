import * as THREE from 'three';
import type { AudioData, LyricsData } from '../types';
import { AudioEngine } from './AudioEngine';
import { Timeline } from './Timeline';
import { BeatSystem } from './BeatSystem';
import { PerformanceManager, type QualityName } from './PerformanceManager';
import { SceneManager } from './SceneManager';
import { PostFX } from '../effects/PostFX';
import { CameraController } from '../camera/CameraController';
import { LyricsRenderer } from '../lyrics/LyricsRenderer';
import { IntroScene, PREROLL } from '../scenes/IntroScene';
import { VoidScene } from '../scenes/VoidScene';
import { NeonGridScene } from '../scenes/NeonGridScene';
import { ParticleStormScene } from '../scenes/ParticleStormScene';
import { CyberCityScene } from '../scenes/CyberCityScene';
import { GlitchScene } from '../scenes/GlitchScene';
import { EnergyCoreScene } from '../scenes/EnergyCoreScene';
import { FinalScene } from '../scenes/FinalScene';
import { Shared } from '../util/shared';
import { DataError } from './DataLoader';
import { clamp } from '../util/math';

export type EngineState = 'idle' | 'preroll' | 'playing' | 'paused' | 'ended';

export interface ProgressHook { (step: 'engine' | 'void', p: number): Promise<void> | void }

/**
 * Owns the renderer and the one render loop. Every frame:
 *   audio.getTime() -> Timeline.update -> BeatSystem events -> SceneManager -> scene.update
 *   -> CameraController -> LyricsRenderer -> PostFX -> render.
 */
export class Engine {
  readonly audio: AudioEngine;
  readonly timeline: Timeline;
  readonly beats: BeatSystem;
  readonly perf = new PerformanceManager('HIGH');
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(60, 1, 0.1, 1200);
  readonly camCtl: CameraController;
  post!: PostFX;
  sceneMgr!: SceneManager;
  lyrics!: LyricsRenderer;
  state: EngineState = 'idle';
  onStateChange: (s: EngineState) => void = () => {};

  private prerollStart = 0;
  private lastNow = 0;
  private real = 0;
  private running = false;
  private el: HTMLElement;
  private w = 1;
  private h = 1;
  private visible = true;

  constructor(parent: HTMLElement, audio: AudioEngine, data: AudioData, lyrics: LyricsData | null) {
    this.el = parent;
    this.audio = audio;
    this.timeline = new Timeline(data, lyrics);
    this.beats = new BeatSystem(this.timeline);
    this.timeline.frame.quality = this.perf.settings;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', alpha: false, stencil: false });
    } catch {
      throw new DataError('WebGL is not available on this device.', 'webgl');
    }
    this.renderer = renderer;
    renderer.setClearColor(0x000004, 1);
    renderer.toneMapping = THREE.NeutralToneMapping; // applied by OutputPass; tames blown-out additive highlights
    renderer.toneMappingExposure = 1;
    parent.appendChild(renderer.domElement);
    renderer.domElement.style.display = 'block';
    this.scene.background = new THREE.Color(0x000004);
    this.camCtl = new CameraController(this.camera);
    this.audio.onEnded = () => this.setState('ended');
    document.addEventListener('visibilitychange', () => (this.visible = !document.hidden));
  }

  /** Builds scenes (the expensive part). Awaits between steps so the loader can animate. */
  async init(hook: ProgressHook) {
    await hook('engine', 0);
    this.post = new PostFX(this.renderer, this.scene, this.camera);
    this.post.setQuality(this.perf.settings);
    this.resize();
    window.addEventListener('resize', () => this.resize());
    this.perf.onChange = () => {
      this.post.setQuality(this.perf.settings);
      this.resize();
    };
    await hook('engine', 1);

    const drums = this.timeline.audio.env.drums;
    const fps = this.timeline.audio.fps;
    const probe = {
      // Last moment (after t0) at which the drum stem is still audible: the outro's "drums stop".
      drumsEndAfter: (t0: number) => {
        for (let i = drums.length - 1; i > t0 * fps; i--) if (drums[i] > 0.06) return i / fps;
        return -1;
      },
    };
    const make = [() => new IntroScene(), () => new VoidScene(), () => new NeonGridScene(), () => new ParticleStormScene(),
      () => new CyberCityScene(), () => new GlitchScene(), () => new EnergyCoreScene(), () => new FinalScene(probe)];
    const scenes = [];
    for (let i = 0; i < make.length; i++) {
      await hook('void', i / make.length);
      scenes.push(make[i]());
    }
    this.sceneMgr = new SceneManager(this.scene, scenes, this.timeline, this.camCtl, this.post);
    this.lyrics = new LyricsRenderer(this.timeline.lyrics);
    this.scene.add(this.lyrics.group);
    this.wireEvents();
    this.sceneMgr.sync(this.timeline.update(0, 0.016, 0, false, -1));
    // Compile every shader up-front so the first transition doesn't hitch.
    scenes.forEach((s) => (s.group.visible = true));
    this.renderer.compile(this.scene, this.camera);
    scenes.forEach((s) => (s.group.visible = s === this.sceneMgr.active));
    await hook('void', 1);
  }

  private wireEvents() {
    const b = this.beats;
    const f = this.timeline.frame;
    const fwd = <K extends keyof import('./BeatSystem').EventMap>(k: K) => b.on(k, (e) => this.sceneMgr.dispatch(k, e, f));
    (['beat', 'downbeat', 'kick', 'snare', 'hat', 'vocal', 'sectionChange', 'lyricStart', 'lyricEnd', 'wordStart'] as const).forEach((k) => fwd(k));
    b.on('kick', (e) => {
      if (e.strength > 0.55) this.post.triggerCA(e.strength * 0.5);
    });
    b.on('snare', (e) => this.post.triggerGlitch(e.strength * 0.18));
    b.on('downbeat', () => {
      this.post.triggerZoom(0.5);
      this.post.triggerFlash(0.12);
    });
    b.on('seek', () => this.sceneMgr.sync(f));
  }

  // ---- transport ----------------------------------------------------------------------
  private setState(s: EngineState) {
    if (this.state === s) return;
    this.state = s;
    this.onStateChange(s);
  }

  /** Play / resume. From the very beginning the silent intro sequence runs first. */
  async play() {
    if (this.state === 'preroll') return;
    if (this.state === 'ended') this.audio.seek(0);
    const fresh = this.audio.currentTime < 0.05;
    if (fresh) {
      this.beats.reset();
      this.lyrics.reset();
      this.prerollStart = performance.now();
      this.setState('preroll');
      return;
    }
    await this.audio.play();
    this.setState('playing');
  }
  pause() {
    if (this.state === 'preroll') {
      this.setState('idle');
      return;
    }
    this.audio.pause();
    this.setState('paused');
  }
  async toggle() {
    if (this.state === 'playing' || this.state === 'preroll') this.pause();
    else await this.play();
  }
  seek(t: number) {
    if (this.state === 'preroll') return;
    this.audio.seek(t);
    if (this.state === 'ended') this.setState('paused');
    this.lyrics.reset();
  }
  seekBy(d: number) {
    this.seek(this.audio.currentTime + d);
  }
  setQuality(q: QualityName) {
    this.perf.setQuality(q);
  }
  resetScene() {
    this.lyrics.reset();
    this.sceneMgr.reset(this.timeline.frame);
  }

  // ---- render loop --------------------------------------------------------------------
  start() {
    if (this.running) return;
    this.running = true;
    this.lastNow = performance.now();
    requestAnimationFrame(this.tick);
  }

  resize() {
    const w = this.el.clientWidth || window.innerWidth;
    const h = this.el.clientHeight || window.innerHeight;
    this.w = w;
    this.h = h;
    const pr = this.perf.pixelRatio();
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.post?.setSize(w, h, pr);
  }

  private tick = (now: number) => {
    requestAnimationFrame(this.tick);
    const dt = Math.min(0.1, Math.max(0.0005, (now - this.lastNow) / 1000));
    this.lastNow = now;
    this.real += dt;

    // Pre-roll: the silent intro, then the music starts.
    let pre = -1;
    if (this.state === 'preroll') {
      pre = (now - this.prerollStart) / 1000 / PREROLL;
      if (pre >= 1) {
        pre = -1;
        this.audio.play().then(() => this.setState('playing'), () => this.setState('paused'));
        this.state = 'playing';
        this.onStateChange('playing');
      }
    }
    const playing = this.state === 'playing' && this.audio.playing;
    let t = this.state === 'preroll' ? 0 : this.audio.getTime();
    if (this.state === 'ended') t = this.timeline.duration;
    t = clamp(t, 0, this.timeline.duration);

    const f = this.timeline.update(t, dt, this.real, playing, pre);
    f.quality = this.perf.settings;
    if (playing || this.state === 'preroll') this.beats.update(t);
    else if (this.state === 'paused' || this.state === 'idle') this.beats.reset();

    this.sceneMgr.update(f);
    const sc = this.sceneMgr.active!;
    sc.update(f, this.perf.settings);

    // camera
    Shared.pointScale.value = (this.renderer.domElement.height || 720) / (2 * Math.tan((this.camera.fov * Math.PI) / 360));
    this.camCtl.update(sc.shot(f), f, dt, this.perf.settings.post > 0.3 ? 1 : 0.4);

    // lyrics float in the world, after the camera has settled
    this.lyrics.update(f, this.camera, this.post.glitchLevel * 0.9, this.perf.settings.lyricDensity, f.sectionName.startsWith('chorus') ? 'hot' : 'normal', dt);

    this.post.fade = sc.fade;
    this.post.update(dt, sc.fx, f.kick, f.bassS, f.rms);
    this.post.render(dt);
    this.perf.tick(dt, this.visible && this.state !== 'idle');
  };

  get frame() {
    return this.timeline.frame;
  }
}
