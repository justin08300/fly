import type { QualitySettings, Section } from '../types';

/**
 * One mutable object, refreshed every frame by Timeline.update().
 * Every scene / effect reads music state from here — nobody owns a private clock.
 */
export class FrameState {
  /** Music time in seconds (audio.currentTime, smoothed). */
  t = 0;
  dt = 0.016;
  /** Real wall-clock seconds (for ambient motion that must continue while paused). */
  real = 0;
  playing = false;
  /** 0..1 progress of the start-up intro sequence, or -1 when not in it. */
  pre = -1;

  bpm = 120;
  beatPeriod = 0.5;
  /** Continuous position in beats (can be negative before the first beat). */
  beatPos = 0;
  beatIndex = 0;
  beatPhase = 0;
  beatInBar = 0;
  barIndex = 0;
  barPhase = 0;
  /** Seconds since the most recent beat / downbeat. */
  sinceBeat = 9;
  sinceDownbeat = 9;

  sectionIndex = 0;
  sectionName = '';
  section: Section = { name: '', start: 0, end: 1 };
  sectionTime = 0;
  sectionProgress = 0;
  /** Bars elapsed since the section started. */
  barInSection = 0;

  // Raw 0..1 envelopes (linear-interpolated from audio.json).
  rms = 0;
  low = 0;
  mid = 0;
  high = 0;
  vocal = 0;
  drums = 0;
  bass = 0;
  other = 0;
  /** Slow-moving overall energy. */
  energy = 0;
  /** Smoothed bass for position/scale (less twitchy than raw). */
  bassS = 0;

  // Decaying onset envelopes (1 at the hit, then falling).
  kick = 0;
  snare = 0;
  hat = 0;
  vocalHit = 0;

  lineIndex = -1;
  wordIndex = -1;
  extraActive = false;

  quality!: QualitySettings;
}
