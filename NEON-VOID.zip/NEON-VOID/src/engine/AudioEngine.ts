import { assetUrl, DataError } from './DataLoader';

/**
 * Thin wrapper over HTMLAudioElement. The music is fetched once and played from a
 * Blob URL, which makes seeking exact and independent of the protocol serving the file.
 * `audio.currentTime` is the single clock that drives everything.
 */
export class AudioEngine {
  private el = new Audio();
  private url = '';
  private lastRaw = 0;
  private lastWall = 0;
  private est = 0;
  /** Visual look-ahead in seconds (positive = visuals slightly early). */
  offset = 0;
  onEnded: (() => void) | null = null;

  async load(onProgress?: (p: number) => void): Promise<void> {
    let res: Response;
    try {
      res = await fetch(assetUrl('pdoom.mp3'));
    } catch {
      throw new DataError('Audio file not found.', 'audio-file');
    }
    if (!res.ok) throw new DataError('Audio file not found.', 'audio-file');
    const total = Number(res.headers.get('Content-Length')) || 0;
    let blob: Blob;
    if (res.body && total) {
      const reader = res.body.getReader();
      const chunks: Uint8Array[] = [];
      let got = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
        got += value.length;
        onProgress?.(got / total);
      }
      blob = new Blob(chunks as BlobPart[], { type: 'audio/mpeg' });
    } else {
      blob = new Blob([await res.arrayBuffer()], { type: 'audio/mpeg' });
    }
    if (blob.size < 1024) throw new DataError('Audio file not found.', 'audio-file');

    this.url = URL.createObjectURL(blob);
    this.el.preload = 'auto';
    this.el.src = this.url;
    await new Promise<void>((resolve, reject) => {
      const ok = () => (cleanup(), resolve());
      const bad = () => (cleanup(), reject(new DataError('Audio file could not be decoded.', 'audio-file')));
      const cleanup = () => {
        this.el.removeEventListener('loadedmetadata', ok);
        this.el.removeEventListener('error', bad);
      };
      this.el.addEventListener('loadedmetadata', ok);
      this.el.addEventListener('error', bad);
    });
    this.el.addEventListener('ended', () => this.onEnded?.());
    this.el.volume = 0.8;
  }

  get duration() {
    return Number.isFinite(this.el.duration) ? this.el.duration : 0;
  }
  get currentTime() {
    return this.el.currentTime;
  }
  get playing() {
    return !this.el.paused && !this.el.ended;
  }
  get ended() {
    return this.el.ended;
  }
  get volume() {
    return this.el.volume;
  }
  set volume(v: number) {
    this.el.volume = Math.min(1, Math.max(0, v));
  }

  async play(): Promise<void> {
    if (this.el.ended) this.seek(0);
    await this.el.play();
  }
  pause() {
    this.el.pause();
  }
  async toggle() {
    if (this.playing) this.pause();
    else await this.play();
  }
  seek(t: number) {
    const d = this.duration || t;
    this.el.currentTime = Math.min(Math.max(0, t), Math.max(0, d - 0.01));
    this.est = this.el.currentTime;
    this.lastRaw = this.el.currentTime;
    this.lastWall = performance.now();
  }

  /**
   * Playback position for visuals. Chromium updates currentTime in coarse steps; between
   * updates we extrapolate with the wall clock (never more than 120 ms) and keep it monotonic.
   */
  getTime(): number {
    const raw = this.el.currentTime;
    const now = performance.now();
    if (this.el.paused || this.el.ended) {
      this.est = raw;
      this.lastRaw = raw;
      this.lastWall = now;
      return raw + this.offset;
    }
    if (raw !== this.lastRaw) {
      this.lastRaw = raw;
      this.lastWall = now;
    }
    let t = raw + Math.min(((now - this.lastWall) / 1000) * this.el.playbackRate, 0.12);
    if (Math.abs(t - this.est) > 0.3) this.est = t;
    else if (t < this.est) t = this.est;
    this.est = t;
    return t + this.offset;
  }

  dispose() {
    this.el.pause();
    if (this.url) URL.revokeObjectURL(this.url);
  }
}
