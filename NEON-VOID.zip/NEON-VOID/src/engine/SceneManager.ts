import type * as THREE from 'three';
import type { BaseScene, SceneId } from '../scenes/BaseScene';
import type { FrameState } from './FrameState';
import type { Timeline } from './Timeline';
import type { EventMap, EventType } from './BeatSystem';
import type { CameraController } from '../camera/CameraController';
import type { PostFX } from '../effects/PostFX';

/** Which world plays during which song section (matched by the section names in audio.json). */
const PLAN: Record<string, [SceneId, number]> = {
  intro: ['intro', 0],
  verse1: ['void', 0],
  pre1: ['grid', 0],
  chorus1: ['storm', 0],
  break1: ['glitch', 1],
  verse2: ['city', 0],
  pre2: ['grid', 1],
  chorus2: ['core', 0],
  verse3: ['glitch', 0],
  pre3: ['void', 1],
  chorus3: ['storm', 1],
  bridge: ['city', 1],
  chorus4: ['core', 1],
  outro: ['final', 0],
};
/** Fallback rotation for section names we have no plan for (other songs / re-analysed data). */
const FALLBACK: [SceneId, number][] = [['void', 0], ['grid', 0], ['storm', 0], ['city', 0], ['glitch', 0], ['core', 0]];

export class SceneManager {
  active: BaseScene | null = null;
  /** Seconds before a section boundary at which the cut happens (hidden by the flash). */
  readonly lead = 0.05;
  private scenes = new Map<SceneId, BaseScene>();
  private lastKey = '';

  constructor(
    private root: THREE.Scene,
    scenes: BaseScene[],
    private tl: Timeline,
    private cam: CameraController,
    private post: PostFX,
  ) {
    scenes.forEach((s) => {
      this.scenes.set(s.id, s);
      root.add(s.group);
    });
  }

  private plan(sectionIndex: number): [SceneId, number] {
    const name = this.tl.audio.sections[sectionIndex].name;
    const key = name.toLowerCase();
    if (PLAN[key] && this.scenes.has(PLAN[key][0])) return PLAN[key];
    if (sectionIndex === this.tl.audio.sections.length - 1) return ['final', 0];
    if (sectionIndex === 0) return ['intro', 0];
    return FALLBACK[sectionIndex % FALLBACK.length];
  }

  /** Jump straight to the right world for time `t` (initial frame, seek, reset). */
  sync(f: FrameState) {
    const [id, variant] = this.plan(f.sectionIndex);
    this.switchTo(id, variant, f, false);
  }

  private switchTo(id: SceneId, variant: number, f: FrameState, flash: boolean) {
    const next = this.scenes.get(id)!;
    const key = `${id}:${variant}:${f.sectionIndex}`;
    if (this.active) this.active.exit();
    this.active = next;
    next.enter(variant, f);
    this.lastKey = key;
    this.cam.snap();
    if (flash) {
      this.post.setFlashColor(next.flashColor);
      this.post.triggerFlash(1);
      this.post.triggerZoom(1);
      this.post.triggerGlitch(0.6);
      this.post.triggerShock(0.5, 0.5);
      this.cam.whip(1);
    }
  }

  /** Called every frame BEFORE scene.update. Cuts slightly early so the flash peaks on the downbeat. */
  update(f: FrameState) {
    if (!this.active) return this.sync(f);
    const lookIdx = this.tl.sectionIndexAt(f.t + this.lead);
    const [id, variant] = this.plan(lookIdx);
    const key = `${id}:${variant}:${lookIdx}`;
    if (key !== this.lastKey) this.switchTo(id, variant, f, true);
  }

  dispatch<K extends EventType>(type: K, e: EventMap[K], f: FrameState) {
    this.active?.onEvent(type, e, f);
  }

  reset(f: FrameState) {
    this.active?.reset(f);
    this.cam.snap();
  }

  dispose() {
    this.scenes.forEach((s) => s.dispose());
  }
}
