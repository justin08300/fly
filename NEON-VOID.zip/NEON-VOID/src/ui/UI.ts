import type { Engine } from '../engine/Engine';
import type { QualityName } from '../engine/PerformanceManager';

const fmt = (s: number) => {
  s = Math.max(0, Math.floor(s));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};

/** Minimal dark-glass HUD + all keyboard controls. */
export class UI {
  private root: HTMLElement;
  private bar!: HTMLElement;
  private fill!: HTMLElement;
  private time!: HTMLElement;
  private playBtn!: HTMLButtonElement;
  private fpsEl!: HTMLElement;
  private qEl!: HTMLElement;
  private toastEl!: HTMLElement;
  private start!: HTMLElement;
  private lastMove = performance.now();
  private toastT = 0;
  private dragging = false;

  constructor(private engine: Engine, private duration: number, notices: string[] = []) {
    this.root = document.getElementById('ui-root')!;
    this.root.innerHTML = `
      <div class="hud">
        <div class="brand">NEON // VOID</div>
        <div class="panel" id="panel">
          <button class="play" id="play" aria-label="Play / Pause">▶</button>
          <div class="track" id="track"><div class="fill" id="fill"></div></div>
          <div class="time" id="time">00:00 / ${fmt(duration)}</div>
          <div class="stat"><span>FPS</span><b id="fps">--</b></div>
          <button class="stat q" id="quality" title="Click or press 1-4"><span>QUALITY</span><b id="qv">HIGH</b></button>
        </div>
        <div class="toast" id="toast"></div>
      </div>
      <div class="start" id="start">
        <button class="enter" id="enter" aria-label="Start">▶</button>
        <div class="hint">SPACE to begin &nbsp;·&nbsp; F fullscreen &nbsp;·&nbsp; 1–4 quality</div>
      </div>`;
    const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
    this.bar = $('track');
    this.fill = $('fill');
    this.time = $('time');
    this.playBtn = $<HTMLButtonElement>('play');
    this.fpsEl = $('fps');
    this.qEl = $('qv');
    this.toastEl = $('toast');
    this.start = $('start');

    this.playBtn.onclick = () => void this.engine.toggle();
    $('enter').onclick = () => void this.engine.play();
    $('quality').onclick = () => (this.engine.perf.cycle(), this.toast(`QUALITY ${this.engine.perf.quality}`));
    this.bar.addEventListener('pointerdown', (e) => {
      this.dragging = true;
      this.bar.setPointerCapture(e.pointerId);
      this.seekFromEvent(e);
    });
    this.bar.addEventListener('pointermove', (e) => this.dragging && this.seekFromEvent(e));
    this.bar.addEventListener('pointerup', () => (this.dragging = false));

    window.addEventListener('mousemove', (e) => {
      this.lastMove = performance.now();
      this.engine.camCtl.pointer.set((e.clientX / window.innerWidth) * 2 - 1, -((e.clientY / window.innerHeight) * 2 - 1));
    });
    window.addEventListener('keydown', (e) => this.onKey(e));
    document.addEventListener('fullscreenchange', () => document.body.classList.toggle('fs', !!document.fullscreenElement));
    engine.onStateChange = () => this.syncPlay();
    this.syncPlay();
    notices.forEach((n) => this.toast(n, 4500));
    setInterval(() => this.refresh(), 100);
  }

  private seekFromEvent(e: PointerEvent) {
    const r = this.bar.getBoundingClientRect();
    this.engine.seek(((e.clientX - r.left) / r.width) * (this.engine.audio.duration || this.duration));
  }

  private onKey(e: KeyboardEvent) {
    const eng = this.engine;
    this.lastMove = performance.now();
    const quality = (n: QualityName) => (eng.setQuality(n), this.toast(`QUALITY ${n}`));
    switch (e.code) {
      case 'Space': e.preventDefault(); void eng.toggle(); break;
      case 'ArrowLeft': e.preventDefault(); eng.seekBy(-5); this.toast('◂ 5s'); break;
      case 'ArrowRight': e.preventDefault(); eng.seekBy(5); this.toast('5s ▸'); break;
      case 'ArrowUp': e.preventDefault(); eng.audio.volume += 0.05; this.toast(`VOLUME ${Math.round(eng.audio.volume * 100)}%`); break;
      case 'ArrowDown': e.preventDefault(); eng.audio.volume -= 0.05; this.toast(`VOLUME ${Math.round(eng.audio.volume * 100)}%`); break;
      case 'KeyF': this.toggleFullscreen(); break;
      case 'Digit1': case 'Numpad1': quality('LOW'); break;
      case 'Digit2': case 'Numpad2': quality('MEDIUM'); break;
      case 'Digit3': case 'Numpad3': quality('HIGH'); break;
      case 'Digit4': case 'Numpad4': quality('ULTRA'); break;
      case 'KeyR': eng.resetScene(); this.toast('SCENE RESET'); break;
      case 'Escape': if (document.fullscreenElement) void document.exitFullscreen(); break;
    }
  }

  toggleFullscreen() {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen().catch(() => {});
  }

  toast(msg: string, ms = 1400) {
    this.toastEl.textContent = msg;
    this.toastEl.classList.add('on');
    clearTimeout(this.toastT);
    this.toastT = window.setTimeout(() => this.toastEl.classList.remove('on'), ms);
  }

  private syncPlay() {
    const s = this.engine.state;
    const running = s === 'playing' || s === 'preroll';
    this.playBtn.textContent = running ? '❚❚' : '▶';
    this.start.classList.toggle('hide', s !== 'idle' || this.engine.audio.currentTime > 0.05);
  }

  private refresh() {
    const e = this.engine;
    const dur = e.audio.duration || this.duration;
    const t = e.state === 'ended' ? dur : e.audio.currentTime;
    this.fill.style.width = `${Math.min(100, (t / dur) * 100)}%`;
    this.time.textContent = `${fmt(t)} / ${fmt(dur)}`;
    this.fpsEl.textContent = String(Math.round(e.perf.fps));
    const rs = e.perf.resolutionScale;
    this.qEl.textContent = e.perf.quality + (rs < 0.995 ? ` ${Math.round(rs * 100)}%` : '');
    // auto-hide
    const idle = performance.now() - this.lastMove > 3000;
    const running = e.state === 'playing' || e.state === 'preroll';
    const fs = !!document.fullscreenElement;
    document.body.classList.toggle('ui-hidden', (fs || running) && idle);
    document.body.classList.toggle('no-cursor', fs && idle);
  }
}

/** Plain, readable failure screen (no stack traces). */
export function showFatal(message: string, detail?: string) {
  document.getElementById('loader')?.remove();
  const d = document.createElement('div');
  d.className = 'fatal';
  d.innerHTML = `<div class="ft-title">NEON // VOID</div><div class="ft-msg"></div><div class="ft-detail"></div>`;
  (d.querySelector('.ft-msg') as HTMLElement).textContent = message;
  (d.querySelector('.ft-detail') as HTMLElement).textContent = detail ?? '';
  document.body.appendChild(d);
}
