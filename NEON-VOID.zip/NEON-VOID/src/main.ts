import '@fontsource/orbitron/500.css';
import '@fontsource/orbitron/700.css';
import '@fontsource/rajdhani/600.css';
import '@fontsource/rajdhani/700.css';
import './ui/ui.css';
import { AudioEngine } from './engine/AudioEngine';
import { DataError, loadAudioJson, loadLyricsJson } from './engine/DataLoader';
import { Engine } from './engine/Engine';
import { UI, showFatal } from './ui/UI';

const nextFrame = () => new Promise<void>((r) => requestAnimationFrame(() => r()));

/** Loading screen: INITIALIZING NEON // VOID  [████░░░░]  + four steps. */
class Loader {
  private bar = document.getElementById('ld-bar')!;
  private el = document.getElementById('loader')!;
  private steps = Array.from(document.querySelectorAll<HTMLElement>('#ld-steps li'));
  private order = ['audio', 'timeline', 'engine', 'void'];
  set(step: string, frac: number, overall: number) {
    const idx = this.order.indexOf(step);
    this.steps.forEach((li, i) => {
      li.classList.toggle('active', i === idx);
      li.classList.toggle('done', i < idx);
    });
    const n = 20;
    const filled = Math.round(Math.min(1, overall) * n);
    this.bar.textContent = `[${'█'.repeat(filled)}${'░'.repeat(n - filled)}]`;
    void frac;
  }
  finish() {
    this.steps.forEach((li) => (li.classList.remove('active'), li.classList.add('done')));
    this.bar.textContent = `[${'█'.repeat(20)}]`;
    this.el.classList.add('done');
    setTimeout(() => this.el.remove(), 1000);
  }
}

async function boot() {
  const loader = new Loader();
  const notices: string[] = [];
  try {
    // 1. audio ---------------------------------------------------------------------------
    loader.set('audio', 0, 0.02);
    const audio = new AudioEngine();
    await audio.load((p) => loader.set('audio', p, 0.02 + p * 0.28));

    // 2. timeline data -------------------------------------------------------------------
    loader.set('timeline', 0, 0.32);
    await nextFrame();
    const data = await loadAudioJson();
    const lyrics = await loadLyricsJson();
    if (!lyrics) notices.push('LYRICS UNAVAILABLE');
    await document.fonts.load("700 100px Rajdhani").catch(() => []);
    await document.fonts.load("700 20px Orbitron").catch(() => []);
    loader.set('timeline', 1, 0.45);

    // 3 + 4. engine + scenes -------------------------------------------------------------
    loader.set('engine', 0, 0.5);
    await nextFrame();
    const engine = new Engine(document.getElementById('stage')!, audio, data, lyrics);
    await engine.init(async (step, p) => {
      loader.set(step, p, step === 'engine' ? 0.5 + p * 0.1 : 0.62 + p * 0.36);
      await nextFrame();
    });
    engine.start();
    new UI(engine, audio.duration || data.duration, notices);
    (window as any).__NEON__ = engine; // handy for debugging in DevTools
    loader.finish();
  } catch (err) {
    console.error('[NEON//VOID]', err);
    if (err instanceof DataError) {
      const extra =
        err.kind === 'audio-file' ? 'Make sure pdoom.mp3 sits next to package.json (or in the app\'s resources folder).' :
        err.kind === 'webgl' ? 'Enable hardware acceleration or update your graphics driver.' : undefined;
      showFatal(err.message, extra);
    } else {
      showFatal('Something went wrong while starting.', err instanceof Error ? err.message : String(err));
    }
  }
}

void boot();
