import * as THREE from 'three';
import { GLSL_COMMON } from '../util/glsl';

/**
 * Neon box material used by monoliths, pillars, city towers, shards and debris.
 *  - glowing edges (thickness in world units, independent of instance scale)
 *  - optional lit-window facades whose cells flash on the beat
 *  - optional "scroll + wrap" so a whole street of instances moves on the GPU
 * `instanceColor` carries per-instance random data (r,g,b are three independent seeds).
 */
export interface BoxMatOptions {
  windows?: boolean;
  loop?: number;       // wrap length along Z (0 = no scroll/wrap)
  zMin?: number;
  edge?: number;       // edge thickness in world units
}

export function makeBoxMaterial(o: BoxMatOptions = {}) {
  const uniforms = {
    uTime: { value: 0 },
    uColA: { value: new THREE.Color('#00f0ff') },
    uColB: { value: new THREE.Color('#39ff88') },
    uColC: { value: new THREE.Color('#9b30ff') },
    uBeat: { value: 0 },        // 0..1 beat flash
    uBeatIdx: { value: 0 },
    uBass: { value: 0 },
    uMid: { value: 0 },
    uKick: { value: 0 },
    uGlow: { value: 1 },
    uScroll: { value: 0 },
    uLoop: { value: o.loop ?? 0 },
    uZMin: { value: o.zMin ?? -200 },
    uFogNear: { value: 20 },
    uFogFar: { value: 220 },
    uFade: { value: 1 },
    uShake: { value: 0 },
    uCollapse: { value: 0 },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms,
    defines: { WINDOWS: o.windows ? 1 : 0, EDGE: (o.edge ?? 0.06).toFixed(3) },
    vertexShader: /* glsl */ `
      uniform float uScroll, uLoop, uZMin, uBass, uShake, uCollapse, uTime;
      varying vec2 vUv; varying vec3 vN; varying vec3 vSeed; varying vec2 vFace; varying float vDepth; varying float vH; varying vec3 vSc;
      ${GLSL_COMMON}
      void main(){
        vUv = uv; vN = normal;
        #ifdef USE_INSTANCING_COLOR
          vSeed = instanceColor;
        #else
          vSeed = vec3(.5);
        #endif
        vec3 sc = vec3(length(instanceMatrix[0].xyz), length(instanceMatrix[1].xyz), length(instanceMatrix[2].xyz));
        vSc = sc;
        vFace = abs(normal.x) > .5 ? sc.zy : abs(normal.y) > .5 ? sc.xz : sc.xy;
        vec4 wp = instanceMatrix * vec4(position, 1.);
        if (uLoop > 0.) wp.z = mod(wp.z + uScroll - uZMin, uLoop) + uZMin;
        // bass shakes buildings along their height; collapse pulls everything toward the axis
        wp.x += sin(uTime * 40. + vSeed.x * 50. + wp.y * .3) * uShake * (.4 + wp.y * .02);
        wp.y *= 1. + uBass * .06 * vSeed.y;
        float kk = clamp((uCollapse - vSeed.x * .4) / .6, 0., 1.);
        wp.xz = rot2(kk * kk * 5.) * wp.xz;
        wp.xz *= 1. - kk;
        wp.y *= 1. - kk * .85;
        vH = position.y;
        vec4 mv = viewMatrix * modelMatrix * wp;
        vDepth = -mv.z;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform float uTime, uBeat, uBeatIdx, uBass, uMid, uKick, uGlow, uFogNear, uFogFar, uFade;
      uniform vec3 uColA, uColB, uColC;
      varying vec2 vUv; varying vec3 vN; varying vec3 vSeed; varying vec2 vFace; varying float vDepth; varying float vH; varying vec3 vSc;
      ${GLSL_COMMON}
      void main(){
        vec3 base = mix(uColA, uColB, step(.7, vSeed.z));
        base = mix(base, uColC, step(.9, vSeed.y));
        vec2 e = min(vUv, 1. - vUv) * vFace;
        float edge = 1. - smoothstep(0., float(EDGE), min(e.x, e.y));
        float edgeSoft = 1. - smoothstep(0., float(EDGE) * 5., min(e.x, e.y));
        float top = step(.5, vN.y);
        vec3 col = vec3(.004, .01, .03);
        col += base * edge * (.8 + uBeat * 1.4 + uKick * .8);
        col += base * edgeSoft * .06;
        #if WINDOWS
          if (abs(vN.y) < .5) {
            vec2 fp = vUv * vFace;
            vec2 cell = floor(fp / vec2(.9, 1.4));
            vec2 cf = fract(fp / vec2(.9, 1.4));
            float on = step(.45, hash21(cell + vSeed.xy * 91.));
            float grp = floor(hash21(cell * 1.7 + vSeed.zx * 13.) * 4.);
            float pulse = step(abs(grp - mod(uBeatIdx, 4.)), .5) * uBeat;
            float flick = step(.985, hash21(cell + floor(uTime * 6.) * 3.1)) * .8;
            float win = step(.18, cf.x) * step(cf.x, .82) * step(.2, cf.y) * step(cf.y, .8);
            vec3 wc = mix(base, vec3(.85, 1., 1.), pulse * .6);
            col += wc * win * on * (.13 + pulse * 1.5 + flick * .6 + uMid * .25);
          }
        #endif
        col += base * top * .05;
        col *= uGlow;
        float fog = 1. - smoothstep(uFogNear, uFogFar, vDepth);
        col *= fog * uFade;
        gl_FragColor = vec4(col, 1.);
      }
    `,
  });
  return mat;
}

/** BoxGeometry with its pivot at the bottom-centre (so scale.y == height). */
export function makeUnitBox(): THREE.BoxGeometry {
  const g = new THREE.BoxGeometry(1, 1, 1);
  g.translate(0, 0.5, 0);
  return g;
}

/**
 * Holographic floating panel (instanced quads): framed rectangle, fake chart bars, scan sweep.
 * Wraps along Z exactly like the box material so whole fields can scroll on the GPU.
 */
export function makePanelMaterial(loop: number, zMin: number) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 }, uScroll: { value: 0 }, uBeat: { value: 0 }, uMid: { value: 0 }, uFade: { value: 1 },
      uColA: { value: new THREE.Color('#00f0ff') }, uColB: { value: new THREE.Color('#39ff88') }, uColC: { value: new THREE.Color('#9b30ff') },
      uLoop: { value: loop }, uZMin: { value: zMin },
    },
    side: THREE.DoubleSide,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      uniform float uScroll, uLoop, uZMin, uTime;
      varying vec2 vUv; varying vec3 vSeed; varying float vDepth;
      void main(){
        vUv = uv;
        #ifdef USE_INSTANCING_COLOR
          vSeed = instanceColor;
        #else
          vSeed = vec3(.5);
        #endif
        vec4 wp = instanceMatrix * vec4(position, 1.);
        wp.z = mod(wp.z + uScroll - uZMin, uLoop) + uZMin;
        wp.y += sin(uTime * .7 + vSeed.x * 20.) * .4;
        vec4 mv = viewMatrix * modelMatrix * wp;
        vDepth = -mv.z;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform float uTime, uBeat, uMid, uFade; uniform vec3 uColA, uColB, uColC;
      varying vec2 vUv; varying vec3 vSeed; varying float vDepth;
      ${GLSL_COMMON}
      void main(){
        vec3 base = mix(uColA, uColB, step(.6, vSeed.z)); base = mix(base, uColC, step(.88, vSeed.y));
        vec2 e = min(vUv, 1. - vUv);
        float frame = 1. - smoothstep(0., .035, min(e.x, e.y));
        float bars = 0.;
        float bx = floor(vUv.x * 14.);
        float bh = .15 + .6 * hash21(vec2(bx, floor(uTime * 2. + vSeed.x * 9.))) * (.5 + uMid);
        bars = step(fract(vUv.x * 14.), .62) * step(vUv.y, bh * .7 + .12) * step(.12, vUv.y) * step(.1, vUv.x) * step(vUv.x, .9);
        float scan = smoothstep(.06, 0., abs(fract(vUv.y - uTime * .25 * (.5 + vSeed.x)) - .5) - .45);
        float lines = .5 + .5 * sin(vUv.y * 120.);
        float a = frame * .9 + bars * .45 + scan * .25 + lines * .04;
        a *= .55 + uBeat * 1.2;
        float fog = 1. - smoothstep(30., 260., vDepth);
        gl_FragColor = vec4(base * a * fog * uFade, a * fog * uFade * .85);
      }`,
  });
}
