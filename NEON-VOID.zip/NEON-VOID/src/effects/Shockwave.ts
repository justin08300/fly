import * as THREE from 'three';

const VERT = /* glsl */ `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }`;
const FRAG = /* glsl */ `
  uniform float uAge, uWidth, uAlpha; uniform vec3 uColor; varying vec2 vUv;
  void main(){
    float d = length(vUv - .5) * 2.;
    float r = uAge;
    float ring = exp(-pow((d - r) / uWidth, 2.));
    float tail = smoothstep(r, r - .35, d) * .12 * (1. - r);
    float a = (ring + tail) * (1. - r) * uAlpha * step(d, 1.);
    gl_FragColor = vec4(uColor * a * 1.6, a);
  }
`;

interface Wave {
  mesh: THREE.Mesh;
  mat: THREE.ShaderMaterial;
  age: number;
  life: number;
  radius: number;
  active: boolean;
}

/** Pool of expanding ring shockwaves (flat quads rendered with a ring shader). */
export class ShockwavePool {
  readonly group = new THREE.Group();
  private waves: Wave[] = [];
  private next = 0;
  private geo = new THREE.PlaneGeometry(1, 1);

  constructor(size = 10) {
    for (let i = 0; i < size; i++) {
      const mat = new THREE.ShaderMaterial({
        vertexShader: VERT,
        fragmentShader: FRAG,
        uniforms: { uAge: { value: 0 }, uWidth: { value: 0.06 }, uAlpha: { value: 1 }, uColor: { value: new THREE.Color('#00f0ff') } },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(this.geo, mat);
      mesh.visible = false;
      mesh.frustumCulled = false;
      this.group.add(mesh);
      this.waves.push({ mesh, mat, age: 0, life: 1, radius: 10, active: false });
    }
  }

  /**
   * @param normal   plane normal (default +Y = a horizontal ring on the ground)
   * @param radius   final radius in world units
   */
  spawn(pos: THREE.Vector3, color: THREE.Color, radius: number, life = 1.1, normal = new THREE.Vector3(0, 1, 0), alpha = 1, width = 0.06) {
    const w = this.waves[this.next++ % this.waves.length];
    w.active = true;
    w.age = 0;
    w.life = life;
    w.radius = radius;
    w.mesh.position.copy(pos);
    w.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal.clone().normalize());
    w.mat.uniforms.uColor.value.copy(color);
    w.mat.uniforms.uAlpha.value = alpha;
    w.mat.uniforms.uWidth.value = width;
    w.mesh.visible = true;
  }

  update(dt: number) {
    for (const w of this.waves) {
      if (!w.active) continue;
      w.age += dt;
      const k = w.age / w.life;
      if (k >= 1) {
        w.active = false;
        w.mesh.visible = false;
        continue;
      }
      // fast out, slow in
      const e = 1 - Math.pow(1 - k, 2.4);
      w.mat.uniforms.uAge.value = e;
      w.mesh.scale.setScalar(w.radius * 2);
    }
  }

  clear() {
    this.waves.forEach((w) => ((w.active = false), (w.mesh.visible = false)));
  }

  dispose() {
    this.geo.dispose();
    this.waves.forEach((w) => w.mat.dispose());
  }
}
