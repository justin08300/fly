import * as THREE from 'three';
import { Shared } from '../util/shared';

/** A single soft glowing sprite (world-sized), used for the intro dot, halos and the void eye. */
export class Glow {
  readonly points: THREE.Points;
  readonly u = {
    uSize: { value: 1 }, uAlpha: { value: 1 }, uPointScale: Shared.pointScale,
    uColor: { value: new THREE.Color('#bffcff') }, uHalo: { value: 0.35 },
  };

  constructor(color = '#bffcff') {
    this.u.uColor.value.set(color);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(3), 3));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
    this.points = new THREE.Points(
      g,
      new THREE.ShaderMaterial({
        uniforms: this.u,
        transparent: true,
        depthWrite: false,
        depthTest: false,
        blending: THREE.AdditiveBlending,
        vertexShader: /* glsl */ `
          uniform float uSize, uPointScale;
          void main(){
            vec4 mv = modelViewMatrix * vec4(position, 1.);
            gl_Position = projectionMatrix * mv;
            gl_PointSize = clamp(uSize * uPointScale / max(-mv.z, .1), 1., 1024.);
          }`,
        fragmentShader: /* glsl */ `
          uniform float uAlpha, uHalo; uniform vec3 uColor;
          void main(){
            float d = length(gl_PointCoord - .5) * 2.;
            if (d > 1.) discard;
            float core = exp(-d * d * 60.);
            float halo = exp(-d * 5.5) * uHalo * (1. - d);
            float a = (core + halo) * uAlpha;
            gl_FragColor = vec4(uColor * a * 1.4, a);
          }`,
      }),
    );
    this.points.frustumCulled = false;
  }

  dispose() {
    this.points.geometry.dispose();
    (this.points.material as THREE.Material).dispose();
  }
}
