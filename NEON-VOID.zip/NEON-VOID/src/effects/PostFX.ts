import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import type { QualitySettings } from '../types';
import { clamp, damp } from '../util/math';
import { GLSL_COMMON } from '../util/glsl';

/**
 * Final "uber" pass: chromatic aberration, lens distortion, screen shockwave, radial motion
 * blur, glitch (row tearing + block noise), scanlines, film grain, vignette, colour grade,
 * flash and fade — all in one full-screen shader so the cost stays flat.
 */
const UberShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    uTime: { value: 0 },
    uSeed: { value: 0 },
    uRes: { value: new THREE.Vector2(1, 1) },
    uAspect: { value: 1 },
    uCA: { value: 0 },
    uGlitch: { value: 0 },
    uDistort: { value: 0 },
    uZoom: { value: 0 },
    uShockC: { value: new THREE.Vector2(0.5, 0.5) },
    uShockR: { value: 0 },
    uShockS: { value: 0 },
    uScan: { value: 0 },
    uGrain: { value: 0 },
    uVignette: { value: 0.5 },
    uGrade: { value: 1 },
    uFlash: { value: 0 },
    uFlashColor: { value: new THREE.Color('#9ff8ff') },
    uFade: { value: 1 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime, uSeed, uAspect, uCA, uGlitch, uDistort, uZoom, uShockR, uShockS, uScan, uGrain, uVignette, uGrade, uFlash, uFade;
    uniform vec2 uRes, uShockC;
    uniform vec3 uFlashColor;
    varying vec2 vUv;
    ${GLSL_COMMON}

    vec3 tap(vec2 uv, vec2 d){
      return vec3(texture2D(tDiffuse, uv + d).r, texture2D(tDiffuse, uv).g, texture2D(tDiffuse, uv - d).b);
    }

    void main(){
      vec2 uv = vUv;
      vec2 c = uv - .5;
      vec2 ca = c * vec2(uAspect, 1.);
      float r2 = dot(ca, ca);

      // lens distortion (breathing barrel)
      uv += c * r2 * uDistort;

      // screen-space shockwave ring
      vec2 sd = (uv - uShockC) * vec2(uAspect, 1.);
      float sl = length(sd);
      float ring = exp(-pow((sl - uShockR) * 14., 2.)) * uShockS;
      uv += sd / (sl + 1e-4) * ring * 0.035;

      // glitch: horizontal row tearing + occasional block shifts
      float g = uGlitch;
      if (g > .001) {
        float rows = mix(18., 70., hash11(uSeed * 1.7));
        float row = floor(uv.y * rows);
        float h = hash21(vec2(row, uSeed));
        float tear = step(1. - g * .45, h);
        uv.x += tear * (hash21(vec2(row + 9., uSeed)) - .5) * .22 * g;
        vec2 blk = floor(uv * vec2(9., 6.));
        float bh = hash21(blk + uSeed * 3.1);
        uv += step(1. - g * .12, bh) * vec2((hash21(blk + 4.) - .5) * .12, 0.);
      }

      float caAmt = uCA + g * .01;
      vec2 dir = c * caAmt * (1. + r2 * 4.);
      vec3 col;
      if (uZoom > .001) {
        col = vec3(0.);
        for (int i = 0; i < 6; i++) {
          float s = float(i) / 5.;
          vec2 p = .5 + (uv - .5) * (1. - uZoom * s);
          col += tap(p, dir * (1. - uZoom * s));
        }
        col /= 6.;
      } else {
        col = tap(uv, dir);
      }

      // digital noise blocks (only while glitching)
      if (g > .001) {
        float nb = step(.996 - g * .01, hash21(floor(uv * vec2(60., 34.)) + uSeed * 5.));
        col += nb * g * vec3(0., .55, .7);
      }

      // colour grade: deep-blue shadows, cool highlights, gentle S-curve
      float lum = dot(col, vec3(.299, .587, .114));
      vec3 graded = mix(col + vec3(0., .004, .02) * (1. - lum), col * vec3(.92, 1.03, 1.1), smoothstep(.2, 1., lum));
      vec3 gc = clamp(graded, 0., 1.);
      graded += (gc * gc * (3. - 2. * gc) - gc) * .35;   // S-curve on the 0..1 part only (never inverts HDR values)
      col = mix(col, graded, uGrade);

      col *= 1. - uScan * (.5 + .5 * sin(vUv.y * uRes.y * 3.14159)) * .35;       // scanlines
      col += (hash21(vUv * uRes + fract(uTime) * 91.) - .5) * uGrain;              // film grain
      col *= 1. - uVignette * smoothstep(.25, 1.05, length(ca * vec2(.9, 1.)));     // vignette
      col += uFlashColor * uFlash;
      col *= uFade;
      gl_FragColor = vec4(max(col, 0.), 1.);
    }
  `,
};

export interface FxParams {
  /** Baseline values a scene wants for itself (0..1-ish). */
  glitch: number;
  ca: number;
  distort: number;
  bloom: number;
  vignette: number;
}

export class PostFX {
  readonly composer: EffectComposer;
  private bloom: UnrealBloomPass;
  private uber: ShaderPass;
  private u = UberShader.uniforms;
  private q!: QualitySettings;

  // Impulses (decay on their own).
  private flash = 0;
  private glitchBurst = 0;
  private caBurst = 0;
  private zoom = 0;
  private shockT = 9;
  private seedClock = 0;
  /** Scene-driven fade multiplier (final scene sets this). */
  fade = 1;
  /** Multiplier on the whole bloom strength (scene baseline). */
  private bloomScene = 1;

  constructor(
    private renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.Camera,
  ) {
    const size = renderer.getDrawingBufferSize(new THREE.Vector2());
    const rt = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType, samples: 0 });
    this.composer = new EffectComposer(renderer, rt);
    this.composer.addPass(new RenderPass(scene, camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 1, 0.6, 0.28);
    this.composer.addPass(this.bloom);
    this.composer.addPass(new OutputPass());
    this.uber = new ShaderPass(new THREE.ShaderMaterial({
      uniforms: THREE.UniformsUtils.clone(UberShader.uniforms),
      vertexShader: UberShader.vertexShader,
      fragmentShader: UberShader.fragmentShader,
    }));
    this.u = this.uber.uniforms as typeof UberShader.uniforms;
    this.composer.addPass(this.uber);
  }

  setQuality(q: QualitySettings) {
    this.q = q;
    this.bloom.enabled = q.bloom;
    this.bloom.radius = q.bloomRadius;
  }

  setSize(w: number, h: number, pixelRatio: number) {
    this.composer.setPixelRatio(pixelRatio);
    this.composer.setSize(w, h);
    const bw = Math.max(64, Math.floor(w * pixelRatio * (this.q?.bloomResolution ?? 0.5)));
    const bh = Math.max(64, Math.floor(h * pixelRatio * (this.q?.bloomResolution ?? 0.5)));
    this.bloom.setSize(bw, bh);
    this.u.uRes.value.set(w * pixelRatio, h * pixelRatio);
    this.u.uAspect.value = w / h;
  }

  // ---- triggers -----------------------------------------------------------------------
  triggerFlash(amount = 1) { this.flash = Math.max(this.flash, amount); }
  triggerGlitch(amount = 1) { this.glitchBurst = Math.max(this.glitchBurst, amount); }
  triggerCA(amount = 1) { this.caBurst = Math.max(this.caBurst, amount); }
  triggerZoom(amount = 1) { this.zoom = Math.max(this.zoom, amount); }
  triggerShock(cx = 0.5, cy = 0.5) { this.shockT = 0; this.u.uShockC.value.set(cx, cy); }
  setFlashColor(c: THREE.Color) { this.u.uFlashColor.value.copy(c); }

  /** Current glitch level (0..1), handy for lyrics etc. */
  get glitchLevel() { return this.u.uGlitch.value as number; }

  update(dt: number, p: FxParams, kick: number, bass: number, rms: number) {
    const q = this.q;
    const post = q.post;
    this.flash = damp(this.flash, 0, 7, dt);
    this.glitchBurst = damp(this.glitchBurst, 0, 9, dt);
    this.caBurst = damp(this.caBurst, 0, 6, dt);
    this.zoom = damp(this.zoom, 0, 7, dt);
    this.shockT += dt;
    this.seedClock += dt;

    const glitch = clamp((p.glitch + this.glitchBurst) * post, 0, 1);
    this.u.uTime.value += dt;
    // The seed steps (not scrolls) so glitch frames look like discrete corruption.
    this.u.uSeed.value = Math.floor(this.seedClock * (glitch > 0.4 ? 22 : 12)) % 997;
    this.u.uGlitch.value = glitch;
    this.u.uCA.value = (p.ca + this.caBurst * 0.012 + kick * 0.0035) * (0.4 + 0.6 * post);
    this.u.uDistort.value = (p.distort + bass * 0.05 + this.caBurst * 0.08) * post;
    this.u.uZoom.value = post > 0.5 ? clamp(this.zoom * 0.07 + kick * 0.012, 0, 0.12) : 0;
    this.u.uShockR.value = this.shockT * 0.9;
    this.u.uShockS.value = clamp(1 - this.shockT / 0.9, 0, 1) * (post > 0.3 ? 1 : 0);
    this.u.uScan.value = post * (0.25 + glitch * 0.6);
    this.u.uGrain.value = 0.045 * post;
    this.u.uVignette.value = p.vignette;
    this.u.uGrade.value = post > 0.3 ? 1 : 0.6;
    this.u.uFlash.value = this.flash * 0.55;
    this.u.uFade.value = this.fade;

    this.bloomScene = p.bloom;
    this.bloom.strength = q.bloomStrength * p.bloom * (0.75 + rms * 0.5 + kick * 0.45);
    this.bloom.threshold = 0.28;
  }

  render(dt: number) {
    this.composer.render(dt);
  }

  dispose() {
    this.composer.dispose();
  }
}
