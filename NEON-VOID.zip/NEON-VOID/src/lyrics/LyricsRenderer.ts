import * as THREE from 'three';
import type { LyricsData } from '../types';
import type { FrameState } from '../engine/FrameState';
import { TextParticles } from './TextParticles';
import { damp } from '../util/math';

interface Slot {
  tp: TextParticles;
  holder: THREE.Group;
  line: number;
}

/**
 * Holographic 3D lyrics. Every line is a particle text object that lives in the Three.js
 * world: it assembles from a scattered cloud, each word lights up when it is sung, then the
 * line is blown apart by wind. The group trails the camera with a soft lag, so it parallaxes
 * against the environment instead of being glued to the screen like a subtitle.
 */
export class LyricsRenderer {
  readonly group = new THREE.Group();
  private slots: Slot[] = [];
  private anchor = new THREE.Vector3();
  private anchorQ = new THREE.Quaternion();
  private fwd = new THREE.Vector3();
  private primed = false;
  private distance = 12.5;
  private tmp = new THREE.Vector3();

  constructor(private lyrics: LyricsData | null, poolSize = 3) {
    for (let i = 0; i < poolSize; i++) {
      const tp = new TextParticles(9000);
      const holder = new THREE.Group();
      holder.add(tp.points);
      this.group.add(holder);
      this.slots.push({ tp, holder, line: -1 });
    }
    this.group.renderOrder = 10;
  }

  reset() {
    this.slots.forEach((s) => ((s.line = -1), s.tp.clear()));
    this.primed = false;
  }

  update(f: FrameState, camera: THREE.PerspectiveCamera, glitch: number, density: number, accent: 'normal' | 'hot', dt: number) {
    // 1. follow the camera with lag
    camera.getWorldDirection(this.fwd);
    this.tmp.copy(camera.position).addScaledVector(this.fwd, this.distance);
    if (!this.primed) {
      this.anchor.copy(this.tmp);
      this.anchorQ.copy(camera.quaternion);
      this.primed = true;
    } else {
      const k = 1 - Math.exp(-5 * Math.min(dt, 0.1));
      this.anchor.lerp(this.tmp, k);
      this.anchorQ.slerp(camera.quaternion, 1 - Math.exp(-4 * Math.min(dt, 0.1)));
    }
    this.group.position.copy(this.anchor);
    this.group.quaternion.copy(this.anchorQ);

    if (!this.lyrics) return;
    const L = this.lyrics.lines;

    // 2. which lines should exist right now
    const want: number[] = [];
    for (let i = 0; i < L.length; i++) {
      if (f.t >= L[i].start - 0.55 && f.t <= L[i].end + 2.4) want.push(i);
      else if (L[i].start - 0.55 > f.t) break;
    }
    // free slots that are no longer wanted
    for (const s of this.slots) if (s.line >= 0 && !want.includes(s.line)) { s.line = -1; s.tp.clear(); }
    // load missing lines
    for (const li of want) {
      if (this.slots.some((s) => s.line === li)) continue;
      const slot = this.slots.find((s) => s.line < 0);
      if (!slot) break;
      const line = L[li];
      const step = Math.max(3, Math.round(4 / Math.sqrt(Math.max(0.3, density))));
      slot.tp.setWords(line.words.map((w) => ({ text: w.w, start: w.start, end: w.end })), { step, keep: density, seed: li + 3 });
      slot.line = li;
      // alternate position so consecutive lines never sit on top of each other
      const side = li % 2 === 0 ? 1 : -1;
      slot.holder.position.set(side * 0.9, side * 1.6, 0);
      slot.holder.rotation.set(0, side * -0.09, side * 0.015);
      (slot.tp.uniforms.uWind.value as THREE.Vector3).set(side * 0.6 + 0.6, 0.35 * side, 0);
    }

    // 3. per-frame uniforms (all share the music clock)
    for (const s of this.slots) {
      const u = s.tp.uniforms;
      u.uTime.value = f.t;
      u.uGlitch.value = glitch;
      u.uEnergy.value = f.vocal;
      u.uPulse.value = f.kick;
      u.uKeep.value = density;
      u.uSize.value = 0.055 * (1 + f.bassS * 0.1);
      (u.uColor.value as THREE.Color).set(accent === 'hot' ? '#4ff7ff' : '#2ad8ff');
      (u.uHot.value as THREE.Color).set(accent === 'hot' ? '#d8ffe6' : '#c8fff0');
      // gentle float
      s.holder.position.y += Math.sin(f.real * 0.9 + s.line) * 0.0008;
    }
    this.distance = damp(this.distance, 12.5 - f.bassS * 1.0, 3, dt);
  }

  dispose() {
    this.slots.forEach((s) => s.tp.dispose());
  }
}
