import * as THREE from 'three';
import { Shared } from '../util/shared';
import { GLSL_COMMON } from '../util/glsl';
import { rng } from '../util/math';

/**
 * Text made of particles. Each particle has a target on the glyph, a scatter start, and four
 * timestamps (form start/end, "sung" start/end). The vertex shader derives everything from one
 * clock uniform, so formation → glow → wind-blown dissolve is deterministic and seek-safe.
 */
const VERT = /* glsl */ `
  attribute vec3 aScatter;
  attribute vec4 aTime;   // formStart, formEnd, singStart, singEnd
  attribute float aRnd;
  uniform float uTime, uSize, uPointScale, uOpacity, uKeep, uGlitch, uEnergy, uPulse;
  uniform vec2 uDissolve;
  uniform vec3 uWind, uColor, uHot;
  varying vec3 vCol; varying float vA; varying float vY;
  ${GLSL_COMMON}
  void main(){
    float f = smoothstep(aTime.x, aTime.y, uTime);
    float e = 1. - pow(1. - f, 3.);
    vec3 start = aScatter + vec3(sin(uTime * 1.3 + aRnd * 20.), cos(uTime * 1.1 + aRnd * 31.), sin(uTime * .9 + aRnd * 13.)) * .5;
    vec3 p = mix(start, position, e);
    // holographic shimmer once formed
    p.xy += vec2(sin(uTime * 3. + aRnd * 60.), cos(uTime * 2.7 + aRnd * 40.)) * .018 * (1. + uEnergy * 2.5);
    // "sung" highlight: word pops toward the viewer and glows
    float sing = smoothstep(aTime.z - .05, aTime.z + .12, uTime) * (1. - smoothstep(aTime.w, aTime.w + .45, uTime));
    p.z += sing * .55 * (.4 + aRnd);
    // dissolve: blown away by wind
    float dd = clamp((uTime - uDissolve.x - aRnd * .55) / max(.01, uDissolve.y - uDissolve.x), 0., 1.);
    vec3 dir = normalize(vec3(uWind.xy + (vec2(aRnd, fract(aRnd * 7.31)) - .5) * 1.4, (aRnd - .5) * .6));
    p += uWind * dd * dd * 9. + dir * dd * 3. + vec3(sin(aRnd * 50. + dd * 6.), cos(aRnd * 40. + dd * 5.), sin(aRnd * 30.)) * dd * 1.4;
    // glitch: row slips
    float row = floor(p.y * 5.);
    p.x += step(.965, hash11(row + floor(uTime * 16.))) * uGlitch * .7;

    vec4 mv = modelViewMatrix * vec4(p, 1.);
    gl_Position = projectionMatrix * mv;
    vA = f * (1. - dd) * uOpacity * step(aRnd, uKeep) * (.5 + sing * .7 + uPulse * .2) * smoothstep(1.5, 6., -mv.z);
    vCol = mix(uColor, uHot, sing);
    vY = p.y;
    float size = uSize * (.65 + aRnd * .7) * (1. + sing * .5 + uEnergy * .2) * (1. - dd * .6);
    gl_PointSize = clamp(size * uPointScale / max(-mv.z, .1), 1., 40.);
  }
`;
const FRAG = /* glsl */ `
  uniform float uTime; varying vec3 vCol; varying float vA; varying float vY;
  void main(){
    float d = length(gl_PointCoord - .5) * 2.;
    if (d > 1.) discard;
    float a = exp(-d * d * 3.6);
    a *= .78 + .22 * sin(vY * 55. - uTime * 11.);   // hologram scanlines
    gl_FragColor = vec4(min(vCol * a * 1.1, vec3(3.)), a * vA);
  }
`;

export interface WordSpec { text: string; start: number; end: number }
export interface TextOptions {
  fontPx?: number;
  /** World units per canvas pixel. */
  scale?: number;
  /** Pixel step of the sampling grid (smaller = denser). */
  step?: number;
  /** Seconds before a word's start at which it begins to form. */
  lead?: number;
  maxRowPx?: number;
  keep?: number;
  /** Seconds after the last word that the dissolve begins. */
  hold?: number;
  dissolve?: number;
  seed?: number;
}

const CW = 2000;
const CH = 520;
let shared: HTMLCanvasElement | null = null;
const getCtx = () => {
  if (!shared) {
    shared = document.createElement('canvas');
    shared.width = CW;
    shared.height = CH;
  }
  return shared.getContext('2d', { willReadFrequently: true })!;
};

export const TEXT_FONT = "700 {px}px Rajdhani, Bahnschrift, 'Segoe UI', 'Arial Narrow', sans-serif";

export class TextParticles {
  readonly points: THREE.Points;
  readonly uniforms: Record<string, THREE.IUniform>;
  private geo = new THREE.BufferGeometry();
  private pos: Float32Array;
  private scatter: Float32Array;
  private times: Float32Array;
  private rnd: Float32Array;
  /** Line index (or any id) currently loaded, -1 if empty. */
  id = -1;
  /** Bounding size of the last layout in world units. */
  width = 0;
  height = 0;

  constructor(readonly capacity = 9000) {
    this.pos = new Float32Array(capacity * 3);
    this.scatter = new Float32Array(capacity * 3);
    this.times = new Float32Array(capacity * 4);
    this.rnd = new Float32Array(capacity);
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    this.geo.setAttribute('aScatter', new THREE.BufferAttribute(this.scatter, 3));
    this.geo.setAttribute('aTime', new THREE.BufferAttribute(this.times, 4));
    this.geo.setAttribute('aRnd', new THREE.BufferAttribute(this.rnd, 1));
    this.geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e3);
    this.geo.setDrawRange(0, 0);
    this.uniforms = {
      uTime: { value: 0 }, uSize: { value: 0.055 }, uPointScale: Shared.pointScale, uOpacity: { value: 1 },
      uKeep: { value: 1 }, uGlitch: { value: 0 }, uEnergy: { value: 0 }, uPulse: { value: 0 },
      uDissolve: { value: new THREE.Vector2(1e9, 1e9 + 1) }, uWind: { value: new THREE.Vector3(1, 0.35, 0) },
      uColor: { value: new THREE.Color('#2ad8ff') }, uHot: { value: new THREE.Color('#c8fff0') },
    };
    this.points = new THREE.Points(
      this.geo,
      new THREE.ShaderMaterial({
        vertexShader: VERT, fragmentShader: FRAG, uniforms: this.uniforms,
        transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending,
      }),
    );
    this.points.frustumCulled = false;
    this.points.renderOrder = 10;
  }

  clear() {
    this.id = -1;
    this.geo.setDrawRange(0, 0);
  }

  /** Lay out `words`, rasterise, and sample into particles. Returns the particle count. */
  setWords(words: WordSpec[], o: TextOptions = {}): number {
    const fontPx = o.fontPx ?? 150;
    const scale = o.scale ?? 0.0092;
    const maxRow = o.maxRowPx ?? 1500;
    const lead = o.lead ?? 0.4;
    const ctx = getCtx();
    ctx.font = TEXT_FONT.replace('{px}', String(fontPx));
    (ctx as any).letterSpacing = `${(fontPx * 0.07).toFixed(1)}px`;
    ctx.textBaseline = 'alphabetic';
    const texts = words.map((w) => w.text.toUpperCase());
    const widths = texts.map((t) => ctx.measureText(t).width);
    const space = fontPx * 0.32;

    // ---- wrap into balanced rows ----
    const total = widths.reduce((a, b) => a + b, 0) + space * Math.max(0, widths.length - 1);
    let rows: number[][] = [words.map((_, i) => i)];
    if (total > maxRow && words.length > 1) {
      const nRows = Math.min(3, Math.ceil(total / maxRow));
      const target = total / nRows;
      rows = [[]];
      let acc = 0;
      words.forEach((_, i) => {
        if (acc + widths[i] / 2 > target * rows.length && rows.length < nRows) rows.push([]);
        rows[rows.length - 1].push(i);
        acc += widths[i] + space;
      });
    }
    const rowW = rows.map((r) => r.reduce((a, i) => a + widths[i], 0) + space * (r.length - 1));
    const lineH = fontPx * 1.12;
    const blockH = rows.length * lineH;
    const y0 = (CH - blockH) / 2 + fontPx * 0.88;

    ctx.clearRect(0, 0, CW, CH);
    ctx.fillStyle = '#fff';
    const boxes: { x0: number; x1: number; y0: number; y1: number; i: number }[] = [];
    rows.forEach((r, ri) => {
      let x = (CW - rowW[ri]) / 2;
      const base = y0 + ri * lineH;
      r.forEach((wi) => {
        ctx.fillText(texts[wi], x, base);
        boxes.push({ x0: x, x1: x + widths[wi], y0: base - fontPx * 0.95, y1: base + fontPx * 0.2, i: wi });
        x += widths[wi] + space;
      });
    });

    // ---- sample ----
    const step = o.step ?? 4;
    const img = ctx.getImageData(0, 0, CW, CH).data;
    const rand = rng(o.seed ?? 7);
    const lastEnd = Math.max(...words.map((w) => w.end));
    let n = 0;
    let minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
    const cap = this.capacity;
    for (let y = 0; y < CH && n < cap; y += step) {
      for (let x = 0; x < CW && n < cap; x += step) {
        if (img[(y * CW + x) * 4 + 3] < 110) continue;
        let box = boxes.find((b) => x >= b.x0 - 2 && x <= b.x1 + 2 && y >= b.y0 && y <= b.y1);
        if (!box) {
          let bd = 1e9;
          for (const b of boxes) {
            const d = Math.abs((b.x0 + b.x1) / 2 - x) + Math.abs((b.y0 + b.y1) / 2 - y) * 2;
            if (d < bd) { bd = d; box = b; }
          }
        }
        const b = box!;
        const frac = (x - b.x0) / Math.max(1, b.x1 - b.x0);
        const w = words[b.i];
        const dur = Math.max(0.05, w.end - w.start);
        const fs = w.start - lead + frac * Math.min(0.45, dur * 0.6);
        const wx = (x - CW / 2 + (rand() - 0.5) * step) * scale;
        const wy = -(y - CH / 2 + (rand() - 0.5) * step) * scale;
        const i3 = n * 3;
        this.pos[i3] = wx;
        this.pos[i3 + 1] = wy;
        this.pos[i3 + 2] = (rand() - 0.5) * 0.25;
        this.scatter[i3] = wx + (rand() - 0.5) * 30;
        this.scatter[i3 + 1] = wy + (rand() - 0.5) * 16;
        this.scatter[i3 + 2] = (rand() - 0.65) * 12;
        const i4 = n * 4;
        this.times[i4] = fs;
        this.times[i4 + 1] = fs + 0.55;
        this.times[i4 + 2] = w.start + frac * dur * 0.2;
        this.times[i4 + 3] = w.end;
        this.rnd[n] = rand();
        minX = Math.min(minX, wx); maxX = Math.max(maxX, wx);
        minY = Math.min(minY, wy); maxY = Math.max(maxY, wy);
        n++;
      }
    }
    this.width = maxX - minX;
    this.height = maxY - minY;
    for (const a of ['position', 'aScatter', 'aTime', 'aRnd']) (this.geo.getAttribute(a) as THREE.BufferAttribute).needsUpdate = true;
    this.geo.setDrawRange(0, n);
    const hold = o.hold ?? 0.15;
    (this.uniforms.uDissolve.value as THREE.Vector2).set(lastEnd + hold, lastEnd + hold + (o.dissolve ?? 1.6));
    this.uniforms.uKeep.value = o.keep ?? 1;
    return n;
  }

  /** Convenience for non-lyric text (the logo): timings are in the caller's clock. */
  setPlain(text: string, formStart: number, formEnd: number, dissolveStart: number, dissolveEnd: number, o: TextOptions = {}) {
    const words = text.split(' ').map((t) => ({ text: t, start: formStart + 0.4, end: formEnd }));
    this.setWords(words, { ...o, lead: 0.4 });
    (this.uniforms.uDissolve.value as THREE.Vector2).set(dissolveStart, dissolveEnd);
  }

  dispose() {
    this.geo.dispose();
    (this.points.material as THREE.Material).dispose();
  }
}
