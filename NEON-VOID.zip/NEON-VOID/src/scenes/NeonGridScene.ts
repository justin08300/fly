import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import type { EventMap, EventType } from '../engine/BeatSystem';
import { ParticleSystem } from '../particles/ParticleSystem';
import { ShockwavePool } from '../effects/Shockwave';
import { makeBoxMaterial, makePanelMaterial, makeUnitBox } from '../effects/Materials';
import { GLSL_COMMON } from '../util/glsl';
import { PALETTE } from '../util/shared';
import { rng } from '../util/math';

const CELL = 4;
const LOOP = 380;
const ZMIN = -370;

function makeGridMaterial(ceiling = false) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uScroll: { value: 0 }, uBass: { value: 0 }, uMid: { value: 0 }, uBeatT: { value: 1 }, uBeatS: { value: 0 }, uBeat: { value: 0 },
      uBeatIdx: { value: 0 }, uTime: { value: 0 }, uCell: { value: CELL }, uGlow: { value: ceiling ? 0.35 : 1 },
      uColA: { value: new THREE.Color('#00f0ff') }, uColB: { value: new THREE.Color('#39ff88') },
    },
    side: THREE.DoubleSide,
    vertexShader: /* glsl */ `
      uniform float uScroll, uBass, uMid, uBeatT, uBeatS, uTime;
      varying vec2 vG; varying float vH; varying float vD;
      void main(){
        vec4 wp = modelMatrix * vec4(position, 1.);
        vec2 g = vec2(wp.x, wp.z - uScroll);
        float side = smoothstep(7., 30., abs(wp.x));
        float terr = sin(g.x * .22 + uTime * .35) * cos(g.y * .17 - uTime * .25) * .5 + .5;
        float h = side * terr * (2.5 + uBass * 14. + uMid * 3.);
        float d = length(wp.xz - vec2(0., -30.));
        h += exp(-pow((d - uBeatT * 90.) * .09, 2.)) * uBeatS * 4.;
        wp.y += h;
        vG = g; vH = h;
        vec4 mv = viewMatrix * wp; vD = -mv.z;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform float uBeat, uBeatT, uBeatIdx, uCell, uGlow; uniform vec3 uColA, uColB;
      varying vec2 vG; varying float vH; varying float vD;
      ${GLSL_COMMON}
      void main(){
        vec2 q = vG / uCell;
        vec2 gr = abs(fract(q - .5) - .5) / fwidth(q);
        float line = 1. - min(min(gr.x, gr.y), 1.);
        vec2 q5 = q / 5.;
        vec2 g5 = abs(fract(q5 - .5) - .5) / fwidth(q5);
        float major = 1. - min(min(g5.x, g5.y), 1.);
        vec3 col = mix(uColA, uColB, smoothstep(0., 9., vH));
        float v = line * .5 + major * .95;
        float flash = step(.94, hash21(floor(q) + floor(uBeatIdx))) * exp(-uBeatT * 5.);
        vec3 o = col * v * (.55 + uBeat * 1.5) + col * flash * .4 + vec3(0., .006, .02);
        o += col * smoothstep(5., 0., vH) * 0. ;
        float fog = 1. - smoothstep(40., 380., vD);
        gl_FragColor = vec4(o * fog * uGlow, 1.);
      }`,
  });
}

/**
 * NEON GRID — an endless 3D grid. One cell scrolls past per half-beat, terrain at the sides
 * rises with bass, every beat sends a ripple, pillars and holographic panels stream by.
 */
export class NeonGridScene extends BaseScene {
  readonly id: SceneId = 'grid';
  private floor: THREE.Mesh;
  private ceil: THREE.Mesh;
  private floorMat = makeGridMaterial(false);
  private ceilMat = makeGridMaterial(true);
  private pillars: THREE.InstancedMesh;
  private pillarMat = makeBoxMaterial({ loop: LOOP, zMin: ZMIN, edge: 0.07 });
  private panels: THREE.InstancedMesh;
  private panelMat = makePanelMaterial(LOOP, ZMIN);
  private sparks = new ParticleSystem({ count: 40000, size: 0.1, seed: 31 });
  private shocks = new ShockwavePool(6);
  private scroll = 0;

  constructor() {
    super();
    const r = rng(77);
    const geo = new THREE.PlaneGeometry(240, LOOP + 40, 150, 220);
    geo.rotateX(-Math.PI / 2);
    this.floor = new THREE.Mesh(geo, this.floorMat);
    this.floor.position.set(0, 0, -LOOP / 2 + 20);
    this.ceil = new THREE.Mesh(geo, this.ceilMat);
    this.ceil.position.set(0, 24, -LOOP / 2 + 20);
    this.ceil.scale.y = -1;
    this.floor.frustumCulled = this.ceil.frustumCulled = false;
    this.group.add(this.floor, this.ceil);

    // pillars
    const N = 150;
    this.pillars = new THREE.InstancedMesh(makeUnitBox(), this.pillarMat, N);
    const m4 = new THREE.Matrix4();
    const seed = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const side = i % 2 ? 1 : -1;
      m4.compose(
        new THREE.Vector3(side * (13 + r() * 36), 0, ZMIN + r() * LOOP),
        new THREE.Quaternion(),
        new THREE.Vector3(0.8 + r() * 1.6, 5 + r() * r() * 34, 0.8 + r() * 1.6),
      );
      this.pillars.setMatrixAt(i, m4);
      seed.set([r(), r(), r()], i * 3);
    }
    this.pillars.instanceColor = new THREE.InstancedBufferAttribute(seed, 3);
    this.pillars.frustumCulled = false;
    this.group.add(this.pillars);

    // floating holographic panels
    const P = 46;
    this.panels = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), this.panelMat, P);
    const pseed = new Float32Array(P * 3);
    for (let i = 0; i < P; i++) {
      const side = r() < 0.5 ? -1 : 1;
      const w = 5 + r() * 7;
      m4.compose(
        new THREE.Vector3(side * (9 + r() * 16), 4 + r() * 13, ZMIN + r() * LOOP),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(0, -side * (0.3 + r() * 0.5), 0)),
        new THREE.Vector3(w, w * (0.5 + r() * 0.3), 1),
      );
      this.panels.setMatrixAt(i, m4);
      pseed.set([r(), r(), r()], i * 3);
    }
    this.panels.instanceColor = new THREE.InstancedBufferAttribute(pseed, 3);
    this.panels.frustumCulled = false;
    this.group.add(this.panels);

    this.group.add(this.sparks.group, this.shocks.group);
    this.fx.ca = 0.0016;
  }

  protected onEnter(): void {
    const v1 = this.variant === 1;
    const a = v1 ? PALETTE.purple : PALETTE.cyan;
    const b = v1 ? PALETTE.cyan : PALETTE.green;
    for (const m of [this.floorMat, this.ceilMat]) {
      m.uniforms.uColA.value.copy(a);
      m.uniforms.uColB.value.copy(b);
    }
    for (const m of [this.pillarMat, this.panelMat]) {
      m.uniforms.uColA.value.copy(a);
      m.uniforms.uColB.value.copy(b);
    }
    this.sparks.uniforms.uColA.value.copy(a);
    this.sparks.uniforms.uColB.value.copy(b);
    this.flashColor.copy(a);
    this.shocks.clear();
  }

  update(f: FrameState, q: QualitySettings): void {
    const v1 = this.variant === 1;
    this.scroll = f.beatPos * CELL * (v1 ? 3 : 2);
    const accent = f.beatInBar === 0 ? 1 : 0.55;
    const beat = Math.exp(-f.sinceBeat * 5.5) * accent;
    for (const m of [this.floorMat, this.ceilMat]) {
      const u = m.uniforms;
      u.uScroll.value = this.scroll;
      u.uBass.value = f.bassS;
      u.uMid.value = f.mid;
      u.uBeatT.value = f.sinceBeat;
      u.uBeatS.value = accent * (0.4 + f.drums * 0.6);
      u.uBeat.value = beat * (0.3 + f.drums);
      u.uBeatIdx.value = f.beatIndex;
      u.uTime.value = f.t;
    }
    for (const m of [this.pillarMat, this.panelMat]) {
      const u = m.uniforms;
      u.uScroll.value = this.scroll;
      u.uTime.value = f.t;
      u.uBeat.value = beat;
      u.uMid.value = f.mid;
      if (u.uBass) { u.uBass.value = f.bassS; u.uKick.value = f.kick; u.uBeatIdx.value = f.beatIndex; }
    }
    this.pillarMat.uniforms.uFogFar.value = 360;
    this.pillars.count = Math.max(30, Math.floor(150 * Math.min(1, q.instanceScale)));
    this.panels.count = Math.max(10, Math.floor(46 * Math.min(1, q.instanceScale)));

    this.sparks.setDensity(q.particleScale / 1.7 * 0.7, 0);
    this.sparks.setMix(1, 0, 0);
    this.sparks.uniforms.uRadius.value = 40;
    this.sparks.uniforms.uOrigin.value.set(0, 10, -30);
    this.sparks.update(f, 0.5 + f.high * 0.5);
    this.shocks.update(f.dt);

    this.fx.glitch = f.hat * 0.04;
    this.fx.bloom = 1 + f.kick * 0.2;
  }

  onEvent<K extends EventType>(type: K, _e: EventMap[K], f: FrameState): void {
    if (type === 'kick') {
      this.shocks.spawn(new THREE.Vector3(0, 0.3, -35), this.variant ? PALETTE.purple : PALETTE.cyan, 70, 1.4, new THREE.Vector3(0, 1, 0), 0.7 * (0.4 + f.drums), 0.05);
    }
  }

  shot(f: FrameState): CameraShot {
    const s = this.shotOut;
    const t = f.sectionTime;
    const v1 = this.variant === 1;
    s.pos.set(Math.sin(t * 0.3) * (v1 ? 5 : 3), (v1 ? 2 : 3) + f.bassS * 0.9 + Math.sin(t * 0.5) * 0.5, 0);
    s.target.set(Math.sin(t * 0.2 + 1) * 8, (v1 ? 3 : 4.5) + Math.sin(t * 0.4) * 1.2, -42);
    s.fov = v1 ? 70 : 64;
    s.roll = Math.sin(t * 0.35) * (v1 ? 0.14 : 0.07);
    s.smooth = 3.2;
    s.shake = 0.09;
    s.bassFov = 7;
    return s;
  }

  dispose() {
    this.floor.geometry.dispose();
    this.floorMat.dispose();
    this.ceilMat.dispose();
    this.pillarMat.dispose();
    this.panelMat.dispose();
    this.pillars.geometry.dispose();
    this.panels.geometry.dispose();
    this.sparks.dispose();
    this.shocks.dispose();
  }
}
