import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import type { EventMap, EventType } from '../engine/BeatSystem';
import { ParticleSystem } from '../particles/ParticleSystem';
import { makeBoxMaterial, makeUnitBox } from '../effects/Materials';
import { GLSL_COMMON } from '../util/glsl';
import { PALETTE } from '../util/shared';
import { rng } from '../util/math';

const LOOP = 300;
const ZMIN = -280;
const N = 520;

/**
 * GLITCH DIMENSION — the world is failing. Shards of geometry stutter forward in 16th-note
 * steps, a corrupted "display" tears behind them, data streams fall, and the post pass
 * tears rows and splits RGB. The glitch amount is driven by snare/hat hits on top of a
 * controlled baseline so the picture never becomes unreadable.
 */
export class GlitchScene extends BaseScene {
  readonly id: SceneId = 'glitch';
  private shards: THREE.InstancedMesh;
  private shardMat = makeBoxMaterial({ loop: LOOP, zMin: ZMIN, edge: 0.1 });
  private screen: THREE.Mesh;
  private screenMat: THREE.ShaderMaterial;
  private rain = new ParticleSystem({ count: 40000, size: 0.12, seed: 51 });
  private seed = 0;

  constructor() {
    super();
    const r = rng(909);
    const m4 = new THREE.Matrix4();
    const seeds = new Float32Array(N * 3);
    this.shards = new THREE.InstancedMesh(makeUnitBox(), this.shardMat, N);
    for (let i = 0; i < N; i++) {
      const a = r() * Math.PI * 2;
      const d = 5 + Math.pow(r(), 0.7) * 38;
      const slab = r() < 0.5;
      m4.compose(
        new THREE.Vector3(Math.cos(a) * d, Math.sin(a) * d * 0.6 + 4, ZMIN + r() * LOOP),
        new THREE.Quaternion().setFromEuler(new THREE.Euler((r() - 0.5) * 0.6, (r() - 0.5) * 0.9, (r() - 0.5) * 1.2)),
        slab ? new THREE.Vector3(3 + r() * 9, 0.4 + r() * 0.8, 1 + r() * 4) : new THREE.Vector3(0.6 + r() * 1.4, 4 + r() * 18, 0.6 + r() * 1.4),
      );
      this.shards.setMatrixAt(i, m4);
      seeds.set([r(), r(), r()], i * 3);
    }
    this.shards.instanceColor = new THREE.InstancedBufferAttribute(seeds, 3);
    this.shards.frustumCulled = false;
    this.shardMat.uniforms.uFogFar.value = 260;
    this.group.add(this.shards);

    this.screenMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uRms: { value: 0 }, uHit: { value: 0 }, uColA: { value: new THREE.Color('#00f0ff') }, uColB: { value: new THREE.Color('#9b30ff') } },
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }`,
      fragmentShader: /* glsl */ `
        uniform float uTime, uRms, uHit; uniform vec3 uColA, uColB; varying vec2 vUv;
        ${GLSL_COMMON}
        void main(){
          vec2 uv = vUv;
          float step_t = floor(uTime * 9.);
          float row = floor(uv.y * 46.);
          float slip = step(.78, hash21(vec2(row, step_t))) * (hash21(vec2(row, step_t + 3.)) - .5) * .35 * (.4 + uHit);
          uv.x += slip;
          vec2 bl = floor(uv * vec2(28., 16.));
          float b = hash21(bl + step_t * 1.7);
          float bars = step(.5, fract(uv.x * 22. + step_t)) * step(.62, hash21(vec2(floor(uv.y * 8.), step_t)));
          vec3 col = uColA * step(.86, b) + uColB * step(.95, b) * 1.2 + uColA * bars * .35;
          float vign = smoothstep(.0, .35, uv.x) * smoothstep(1., .65, uv.x) * smoothstep(0., .25, uv.y) * smoothstep(1., .75, uv.y);
          col *= vign * (.35 + uRms * .9 + uHit * .8);
          col += uColA * (1. - smoothstep(0., .02, abs(uv.y - fract(uTime * .35)))) * .3;
          gl_FragColor = vec4(col, 1.);
        }`,
    });
    this.screen = new THREE.Mesh(new THREE.PlaneGeometry(240, 130), this.screenMat);
    this.screen.position.set(0, 12, -150);
    this.screen.frustumCulled = false;
    this.group.add(this.screen, this.rain.group);
    this.fx.ca = 0.004;
  }

  protected onEnter(): void {
    const burst = this.variant === 1;
    this.shardMat.uniforms.uColA.value.copy(burst ? PALETTE.purple : PALETTE.cyan);
    this.shardMat.uniforms.uColB.value.copy(PALETTE.white);
    this.shardMat.uniforms.uColC.value.copy(PALETTE.purple);
    this.rain.uniforms.uColA.value.copy(PALETTE.green);
    this.rain.uniforms.uColB.value.copy(PALETTE.cyan);
    this.flashColor.copy(burst ? PALETTE.purple : PALETTE.white);
  }

  update(f: FrameState, q: QualitySettings): void {
    const burst = this.variant === 1;
    // stutter: world advances in 16th-note steps instead of smoothly
    const stepPos = Math.floor(f.beatPos * 4) / 4;
    const u = this.shardMat.uniforms;
    u.uScroll.value = stepPos * 16;
    u.uTime.value = Math.floor(f.t * 12) / 12;
    u.uBeat.value = Math.exp(-f.sinceBeat * 7) * (0.3 + f.drums);
    u.uKick.value = f.kick;
    u.uBass.value = f.bassS;
    u.uShake.value = 0.2 + f.snare * 0.9 + f.hat * 0.3;
    u.uGlow.value = 0.8 + f.energy * 0.9;
    this.shards.count = Math.max(100, Math.floor(N * Math.min(1, q.instanceScale)));

    const hit = Math.max(f.snare, f.hat * 0.5);
    this.screenMat.uniforms.uTime.value = f.t;
    this.screenMat.uniforms.uRms.value = f.rms;
    this.screenMat.uniforms.uHit.value = hit;

    this.rain.setDensity(q.particleScale / 1.7 * 0.55, 0);
    this.rain.setMix(0, 1, 0);
    this.rain.uniforms.uTunnelR.value = 32;
    this.rain.uniforms.uTwist.value = 0;
    this.rain.uniforms.uSpin.value = 0;
    this.rain.uniforms.uSpeed.value = 70;
    this.rain.uniforms.uTunnelLen.value = 160;
    this.rain.update(f, 0.7);

    // controlled glitch: baseline + percussive spikes, hard-capped
    const base = burst ? 0.5 : 0.16;
    this.fx.glitch = Math.min(0.85, base + f.snare * 0.4 + f.hat * 0.12);
    this.fx.ca = 0.003 + f.snare * 0.004;
    this.fx.distort = 0.03 + f.snare * 0.05;
    this.seed = f.beatIndex;
  }

  onEvent<K extends EventType>(type: K, _e: EventMap[K], f: FrameState): void {
    void f;
    if (type === 'snare') this.shotOut.roll = (Math.random() - 0.5) * 0.3; // overwritten by shot(), flavour only
  }

  shot(f: FrameState): CameraShot {
    const s = this.shotOut;
    // quantised camera "snaps": position/roll jump every half beat, then settle quickly
    const q = Math.floor(f.beatPos * 2);
    const h = (n: number) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
    s.pos.set((h(q) - 0.5) * 7, 4 + (h(q + 9) - 0.5) * 5, 0);
    s.target.set((h(q + 3) - 0.5) * 6, 4 + (h(q + 5) - 0.5) * 3, -40);
    s.fov = 70;
    s.roll = (h(q + 7) - 0.5) * 0.35 * (this.variant === 1 ? 1.4 : 1);
    s.smooth = 16;
    s.shake = 0.18;
    s.bassFov = 8;
    return s;
  }

  dispose() {
    this.shards.geometry.dispose();
    this.shardMat.dispose();
    this.screen.geometry.dispose();
    this.screenMat.dispose();
    this.rain.dispose();
  }
}
