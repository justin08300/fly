import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import type { EventMap, EventType } from '../engine/BeatSystem';
import { ShockwavePool } from '../effects/Shockwave';
import { makeBoxMaterial, makePanelMaterial, makeUnitBox } from '../effects/Materials';
import { Shared, PALETTE } from '../util/shared';
import { GLSL_COMMON } from '../util/glsl';
import { rng, lerp } from '../util/math';

const LOOP = 420;
const ZMIN = -400;
const MAX_TOWERS = 1500;

/**
 * CYBER CITY — procedural, abstract. Towers with beat-flashing window grids, neon road with
 * moving lane dashes, streams of traffic lights, floating signs and holograms. The camera
 * flies fast and banks through the avenues; bass shakes the buildings.
 */
export class CyberCityScene extends BaseScene {
  readonly id: SceneId = 'city';
  private towers: THREE.InstancedMesh;
  private towerMat = makeBoxMaterial({ windows: true, loop: LOOP, zMin: ZMIN, edge: 0.09 });
  private signs: THREE.InstancedMesh;
  private signMat = makePanelMaterial(LOOP, ZMIN);
  private road: THREE.Mesh;
  private roadMat: THREE.ShaderMaterial;
  private traffic: THREE.Points;
  private trafficMat: THREE.ShaderMaterial;
  private holos: THREE.Mesh[] = [];
  private shocks = new ShockwavePool(6);
  private scroll = 0;

  constructor() {
    super();
    const r = rng(303);
    const m4 = new THREE.Matrix4();
    const seeds = new Float32Array(MAX_TOWERS * 3);
    this.towers = new THREE.InstancedMesh(makeUnitBox(), this.towerMat, MAX_TOWERS);
    let n = 0;
    // main towers on a street grid, then annexes and spires so the skyline has layers
    const place = (x: number, z: number, w: number, d: number, h: number) => {
      if (n >= MAX_TOWERS) return;
      m4.compose(new THREE.Vector3(x, 0, z), new THREE.Quaternion(), new THREE.Vector3(w, h, d));
      this.towers.setMatrixAt(n, m4);
      seeds.set([r(), r(), r()], n * 3);
      n++;
    };
    for (let gz = 0; gz < 34; gz++) {
      for (let gx = -11; gx <= 11; gx++) {
        if (Math.abs(gx) <= 0) continue;
        const side = Math.sign(gx);
        const x = side * (12 + (Math.abs(gx) - 1) * 12) + (r() - 0.5) * 2.2;
        const z = ZMIN + gz * (LOOP / 34) + (r() - 0.5) * 2;
        const center = 1 - Math.abs(gx) / 12;
        const h = 8 + Math.pow(r(), 2.1) * 80 * (0.5 + center);
        place(x, z, 5 + r() * 5, 5 + r() * 5, h);
        if (r() < 0.55) place(x + side * (r() * 3), z + (r() - 0.5) * 3, 2.5 + r() * 3, 2.5 + r() * 3, h * (0.25 + r() * 0.4) + 14);
        if (r() < 0.25) place(x, z, 0.8, 0.8, h + 8 + r() * 16);
      }
    }
    this.towers.count = n;
    this.towers.instanceColor = new THREE.InstancedBufferAttribute(seeds, 3);
    this.towers.frustumCulled = false;
    this.towerMat.uniforms.uFogFar.value = 300;
    this.group.add(this.towers);
    (this.towers.userData as any).total = n;

    // signs
    const S = 70;
    this.signs = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), this.signMat, S);
    const ss = new Float32Array(S * 3);
    for (let i = 0; i < S; i++) {
      const side = r() < 0.5 ? -1 : 1;
      const w = 4 + r() * 6;
      m4.compose(
        new THREE.Vector3(side * (10 + r() * 6), 9 + r() * 34, ZMIN + r() * LOOP),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(0, side * (Math.PI / 2 - 0.25 - r() * 0.4), 0)),
        new THREE.Vector3(w, w * (0.4 + r() * 0.8), 1),
      );
      this.signs.setMatrixAt(i, m4);
      ss.set([r(), r(), r()], i * 3);
    }
    this.signs.instanceColor = new THREE.InstancedBufferAttribute(ss, 3);
    this.signs.frustumCulled = false;
    this.group.add(this.signs);

    // road
    this.roadMat = new THREE.ShaderMaterial({
      uniforms: { uScroll: { value: 0 }, uBeat: { value: 0 }, uBeatPos: { value: 0 }, uColA: { value: new THREE.Color('#00f0ff') }, uColB: { value: new THREE.Color('#9b30ff') } },
      vertexShader: `varying vec3 vW; varying float vD; void main(){ vec4 wp = modelMatrix * vec4(position, 1.); vW = wp.xyz; vec4 mv = viewMatrix * wp; vD = -mv.z; gl_Position = projectionMatrix * mv; }`,
      fragmentShader: /* glsl */ `
        uniform float uScroll, uBeat, uBeatPos; uniform vec3 uColA, uColB; varying vec3 vW; varying float vD;
        ${GLSL_COMMON}
        void main(){
          float z = vW.z - uScroll;
          float ax = abs(vW.x);
          float dash = step(.5, fract(z / 7.)) * (1. - smoothstep(.1, .3, ax));
          float edge = 1. - smoothstep(0., .22, abs(ax - 9.));
          float lane = 1. - smoothstep(0., .1, abs(ax - 4.5)); lane *= step(.35, fract(z / 3.));
          float cross = 1. - smoothstep(0., .25, abs(fract(z / 14. ) - .5) * 14. - 6.6);
          float wv = mod(-z * .05 - uBeatPos, 4.) - 2.;
          float wave = exp(-wv * wv * 2.);
          vec3 col = uColA * (dash * 1.2 + lane * .5) + uColB * edge * 1.1 + uColA * cross * .25;
          col += uColA * wave * .06 * (1. - smoothstep(9., 12., ax));
          col *= .6 + uBeat * 1.4;
          col += vec3(0., .004, .014);
          gl_FragColor = vec4(col * (1. - smoothstep(30., 320., vD)), 1.);
        }`,
    });
    this.road = new THREE.Mesh(new THREE.PlaneGeometry(400, LOOP + 60).rotateX(-Math.PI / 2), this.roadMat);
    this.road.position.set(0, 0, ZMIN + LOOP / 2 + 30);
    this.road.frustumCulled = false;
    this.group.add(this.road);

    // traffic: GPU points streaming along lanes
    const T = 1400;
    const pos = new Float32Array(T * 3);
    const sd = new Float32Array(T * 4);
    for (let i = 0; i < T; i++) sd.set([r(), r(), r(), r()], i * 4);
    const tg = new THREE.BufferGeometry();
    tg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    tg.setAttribute('aSeed', new THREE.BufferAttribute(sd, 4));
    tg.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
    this.trafficMat = new THREE.ShaderMaterial({
      uniforms: { uScroll: { value: 0 }, uBeat: { value: 0 }, uPointScale: Shared.pointScale, uKeep: { value: 1 }, uColA: { value: new THREE.Color('#00f0ff') }, uColB: { value: new THREE.Color('#ff2b6e') }, uColC: { value: new THREE.Color('#9b30ff') } },
      transparent: true, depthWrite: false, depthTest: true, blending: THREE.AdditiveBlending,
      vertexShader: /* glsl */ `
        attribute vec4 aSeed; uniform float uScroll, uBeat, uPointScale, uKeep; uniform vec3 uColA, uColB, uColC;
        varying vec3 vC; varying float vA;
        void main(){
          float lane = floor(aSeed.x * 6.);
          float oncoming = step(3., lane);
          float x = (oncoming > .5 ? 1.8 + (lane - 3.) * 2.3 : -1.8 - lane * 2.3) + (aSeed.y - .5) * .5;
          float spd = oncoming > .5 ? 1.45 : .45;
          float z = mod(aSeed.z * ${LOOP.toFixed(1)} + uScroll * spd, ${LOOP.toFixed(1)}) + ${ZMIN.toFixed(1)};
          vec3 p = vec3(x, .5 + aSeed.w * 1.2 + step(.93, aSeed.y) * 6., z);
          vec4 mv = viewMatrix * modelMatrix * vec4(p, 1.);
          gl_Position = projectionMatrix * mv;
          vC = oncoming > .5 ? mix(uColA, vec3(1.), .5) : uColB; vC = mix(vC, uColC, step(.9, aSeed.w));
          vA = step(aSeed.w, uKeep) * (1. - smoothstep(60., 300., -mv.z)) * smoothstep(.5, 4., -mv.z) * (.7 + uBeat);
          gl_PointSize = clamp(.5 * uPointScale / max(-mv.z, .1), 1., 14.);
        }`,
      fragmentShader: `varying vec3 vC; varying float vA; void main(){ float d = length(gl_PointCoord - .5) * 2.; if (d > 1.) discard; float a = exp(-d * d * 4.); gl_FragColor = vec4(vC * a * 1.6, a * vA); }`,
    });
    this.traffic = new THREE.Points(tg, this.trafficMat);
    this.traffic.frustumCulled = false;
    this.group.add(this.traffic);

    // holograms: rotating wire figures that float over the road
    const hg = [new THREE.OctahedronGeometry(1, 0), new THREE.TorusKnotGeometry(0.7, 0.18, 90, 8), new THREE.IcosahedronGeometry(1, 1)];
    for (let i = 0; i < 7; i++) {
      const m = new THREE.Mesh(
        hg[i % 3],
        new THREE.MeshBasicMaterial({ color: i % 2 ? PALETTE.cyan : PALETTE.purple, wireframe: true, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false }),
      );
      m.userData.z0 = r() * LOOP;
      m.userData.x = (r() - 0.5) * 12;
      m.userData.y = 7 + r() * 14;
      m.scale.setScalar(2.5 + r() * 3);
      this.holos.push(m);
      this.group.add(m);
    }
    this.group.add(this.shocks.group);
    this.fx.ca = 0.0022;
    this.fx.distort = 0.015;
    this.fx.bloom = 0.7;
  }

  protected onEnter(): void {
    const v1 = this.variant === 1;
    const a = v1 ? PALETTE.green : PALETTE.cyan;
    const b = v1 ? PALETTE.purple : PALETTE.deepBlue;
    this.towerMat.uniforms.uColA.value.copy(a);
    this.towerMat.uniforms.uColB.value.copy(v1 ? PALETTE.cyan : PALETTE.green);
    this.towerMat.uniforms.uColC.value.copy(PALETTE.purple);
    this.signMat.uniforms.uColA.value.copy(a);
    this.roadMat.uniforms.uColA.value.copy(a);
    this.roadMat.uniforms.uColB.value.copy(v1 ? PALETTE.purple : new THREE.Color('#2a6bff'));
    this.trafficMat.uniforms.uColA.value.copy(a);
    void b;
    this.flashColor.copy(a);
    this.shocks.clear();
  }

  update(f: FrameState, q: QualitySettings): void {
    const v1 = this.variant === 1;
    this.scroll = f.beatPos * (v1 ? 30 : 22);
    const beat = Math.exp(-f.sinceBeat * 6) * (f.beatInBar === 0 ? 1 : 0.65);
    const tu = this.towerMat.uniforms;
    tu.uScroll.value = this.scroll;
    tu.uTime.value = f.t;
    tu.uBeat.value = beat * (0.3 + f.drums * 0.9);
    tu.uBeatIdx.value = f.beatIndex;
    tu.uBass.value = f.bassS;
    tu.uMid.value = f.mid;
    tu.uKick.value = f.kick;
    tu.uShake.value = f.bassS * 0.28 + f.kick * 0.2;
    tu.uGlow.value = 0.6 + f.energy * 0.45;
    this.towers.count = Math.max(300, Math.floor((this.towers.userData as any).total * Math.min(1, q.instanceScale)));

    const su = this.signMat.uniforms;
    su.uScroll.value = this.scroll;
    su.uTime.value = f.t;
    su.uBeat.value = beat;
    su.uMid.value = f.mid;
    this.signs.count = Math.max(15, Math.floor(70 * Math.min(1, q.instanceScale)));

    this.roadMat.uniforms.uScroll.value = this.scroll;
    this.roadMat.uniforms.uBeat.value = beat * 0.8 + f.low * 0.3;
    this.roadMat.uniforms.uBeatPos.value = f.beatPos;
    this.trafficMat.uniforms.uScroll.value = this.scroll;
    this.trafficMat.uniforms.uBeat.value = beat;
    this.trafficMat.uniforms.uKeep.value = Math.min(1, q.instanceScale);

    this.holos.forEach((h, i) => {
      const z = ((h.userData.z0 + this.scroll) % LOOP) + ZMIN;
      h.position.set(h.userData.x, h.userData.y + Math.sin(f.t + i) * 1.2, z);
      h.rotation.y += f.dt * (0.6 + i * 0.1);
      h.rotation.x += f.dt * 0.3;
      (h.material as THREE.MeshBasicMaterial).opacity = 0.35 + beat * 0.6;
    });
    this.shocks.update(f.dt);
    this.fx.glitch = f.snare * 0.06;
    this.fx.ca = 0.002 + f.bassS * 0.002;
  }

  onEvent<K extends EventType>(type: K, _e: EventMap[K], f: FrameState): void {
    if (type === 'downbeat') {
      const p = new THREE.Vector3(0, 0.2, this.shotOut.pos.z - 30);
      this.shocks.spawn(p, this.variant ? PALETTE.green : PALETTE.cyan, 60, 1.3, new THREE.Vector3(0, 1, 0), 0.9, 0.04);
    }
    void f;
  }

  shot(f: FrameState): CameraShot {
    const s = this.shotOut;
    const t = f.t;
    const v1 = this.variant === 1;
    const sway = Math.sin(t * (v1 ? 0.7 : 0.45));
    s.pos.set(sway * (v1 ? 6 : 4.5), (v1 ? 5.5 : 10) + Math.sin(t * 0.7) * 2.5 + f.bassS * 1.4, 0);
    s.target.set(sway * 2.2 + Math.sin(t * 0.3) * 3, (v1 ? 5 : 8) + Math.sin(t * 0.5), -40);
    s.fov = lerp(68, 78, f.energy) + (v1 ? 4 : 0);
    s.roll = -Math.cos(t * (v1 ? 0.7 : 0.45)) * (v1 ? 0.22 : 0.15);
    s.smooth = 4.5;
    s.shake = 0.16;
    s.bassFov = 8;
    return s;
  }

  dispose() {
    this.towers.geometry.dispose();
    this.towerMat.dispose();
    this.signs.geometry.dispose();
    this.signMat.dispose();
    this.road.geometry.dispose();
    this.roadMat.dispose();
    this.traffic.geometry.dispose();
    this.trafficMat.dispose();
    this.shocks.dispose();
  }
}
