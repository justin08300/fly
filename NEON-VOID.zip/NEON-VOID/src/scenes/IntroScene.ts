import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import type { EventMap, EventType } from '../engine/BeatSystem';
import { Glow } from '../effects/Glow';
import { ShockwavePool } from '../effects/Shockwave';
import { ParticleSystem } from '../particles/ParticleSystem';
import { TextParticles } from '../lyrics/TextParticles';
import { PALETTE } from '../util/shared';
import { smoothstep } from '../util/math';

/** Length (seconds) of the silent start-up sequence before the music begins. */
export const PREROLL = 3.6;

/**
 * INTRO — black. One faint light breathes. Particles gather into NEON // VOID, the logo is
 * "activated", then dissolves as the music (and the world) starts.
 */
export class IntroScene extends BaseScene {
  readonly id: SceneId = 'intro';
  private dot = new Glow('#bffcff');
  private logo = new TextParticles(7000);
  private dust = new ParticleSystem({ count: 9000, size: 0.09, seed: 11 });
  private shocks = new ShockwavePool(6);
  private activated = false;

  constructor() {
    super();
    this.logo.points.position.set(0, 0, 0);
    this.group.add(this.dust.group, this.logo.points, this.dot.points, this.shocks.group);
    this.dust.uniforms.uRadius.value = 26;
    this.fx.vignette = 0.75;
    this.fx.bloom = 1.25;
  }

  /** Clock for this scene: pre-roll first, then the song's own time. */
  private introT(f: FrameState) {
    return f.pre >= 0 ? f.pre * PREROLL : PREROLL + f.t;
  }

  protected onEnter(): void {
    this.activated = false;
    this.shocks.clear();
    this.logo.setPlain('NEON // VOID', 0.5, 2.7, 3.15, 4.7, { fontPx: 170, scale: 0.0115, step: 5, hold: 0 });
  }

  update(f: FrameState, q: QualitySettings): void {
    // Before Play is pressed (idle at 0:00) only the dot breathes in the dark.
    const idle = f.pre < 0 && !f.playing && f.t < 0.05;
    const t = idle ? 0 : this.introT(f);
    const dotT = idle ? 1.2 : t;
    // The dot: fades in, breathes slowly, then locks to the beat once music runs.
    const appear = smoothstep(0.1, 0.9, dotT);
    const breathe = f.pre >= 0 || idle ? 0.5 + 0.5 * Math.sin(f.real * 2.4) : Math.exp(-f.sinceBeat * 7) ;
    const gone = 1 - smoothstep(1.4, 2.6, dotT);
    this.dot.u.uSize.value = 0.42 + breathe * 0.28;
    this.dot.u.uAlpha.value = appear * (0.55 + breathe * 0.45) * (0.15 + 0.85 * gone);

    // Logo
    this.logo.uniforms.uTime.value = t;
    this.logo.uniforms.uPulse.value = 0.5 + 0.5 * Math.sin(f.real * 3.0);
    this.logo.uniforms.uKeep.value = q.lyricDensity;
    this.logo.uniforms.uSize.value = 0.08;
    this.logo.uniforms.uOpacity.value = 2.2;
    (this.logo.uniforms.uWind.value as THREE.Vector3).set(0.8, 0.2, 0);

    // Faint particles condense in the dark
    this.dust.setDensity(q.particleScale / 1.7 * 0.8, 0);
    this.dust.setMix(1, 0, 0);
    this.dust.update(f, smoothstep(0.8, 2.5, t) * 0.5);

    // "world activated" — first shockwave when the music starts
    if (!this.activated && f.pre < 0 && f.playing) {
      this.activated = true;
      this.shocks.spawn(new THREE.Vector3(0, 0, 0), PALETTE.cyan, 9, 1.8, new THREE.Vector3(0, 0, 1), 0.5, 0.04);
    }
    this.shocks.update(f.dt);
  }

  onEvent<K extends EventType>(type: K, _e: EventMap[K], f: FrameState): void {
    if (type === 'beat') this.shocks.spawn(new THREE.Vector3(0, 0, 0), PALETTE.cyan, 4, 1.1, new THREE.Vector3(0, 0, 1), 0.3, 0.04);
  }

  shot(f: FrameState): CameraShot {
    const t = this.introT(f);
    const s = this.shotOut;
    const k = Math.min(1, t / 6);
    s.pos.set(Math.sin(t * 0.3) * 0.8, Math.cos(t * 0.23) * 0.4, 20 - k * 6);
    s.target.set(0, 0, 0);
    s.fov = 50;
    s.roll = 0;
    s.smooth = 3;
    s.shake = 0.02;
    s.bassFov = 2;
    return s;
  }

  dispose() {
    this.dot.dispose();
    this.logo.dispose();
    this.dust.dispose();
    this.shocks.dispose();
  }
}
