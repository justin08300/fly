import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import { ParticleSystem } from '../particles/ParticleSystem';
import { Glow } from '../effects/Glow';
import { ShockwavePool } from '../effects/Shockwave';
import { makeBoxMaterial, makeUnitBox } from '../effects/Materials';
import { TextParticles } from '../lyrics/TextParticles';
import { GLSL_COMMON } from '../util/glsl';
import { PALETTE } from '../util/shared';
import { rng, smoothstep } from '../util/math';

/**
 * FINAL — everything is pulled into a central Void. The outro section drives it:
 *   collapse 0..1 over the loud part (until the drums stop), light dies, then black, and only
 *   NEON // VOID is left. All timings are fractions of the section's own start/end from
 *   audio.json, plus the moment the drums envelope falls silent — nothing is hard-coded to seconds.
 */
export class FinalScene extends BaseScene {
  readonly id: SceneId = 'final';
  private ps = new ParticleSystem({ count: 120000, size: 0.14, seed: 71 });
  private grid: THREE.Mesh;
  private gridMat: THREE.ShaderMaterial;
  private towers: THREE.InstancedMesh;
  private towerMat = makeBoxMaterial({ edge: 0.1 });
  private towerBase: { x: number; z: number; h: number; w: number }[] = [];
  private disc: THREE.Mesh;
  private discMat: THREE.ShaderMaterial;
  private hole = new THREE.Mesh(new THREE.SphereGeometry(5, 32, 16), new THREE.MeshBasicMaterial({ color: 0x000000 }));
  private halo = new Glow('#5ff6ff');
  private shocks = new ShockwavePool(5);
  private logo = new TextParticles(7000);
  private logoBuilt = false;
  private dummy = new THREE.Object3D();
  /** Seconds (song time) of the key moments, resolved from the data in setTimes(). */
  private tCollapseEnd = 153;
  private tDark = 155.4;
  private tLogo = 154.2;
  private tEnd = 156.6;

  constructor(private envProbe: { drumsEndAfter: (t: number) => number }) {
    super();
    const r = rng(1234);
    // collapsing floor grid
    this.gridMat = new THREE.ShaderMaterial({
      uniforms: { uK: { value: 0 }, uT: { value: 0 }, uFade: { value: 1 }, uBeat: { value: 0 }, uColA: { value: new THREE.Color('#00f0ff') } },
      side: THREE.DoubleSide,
      vertexShader: /* glsl */ `
        uniform float uK, uT; varying vec2 vG; varying float vR; varying float vD;
        ${GLSL_COMMON}
        void main(){
          vec3 p = position; vG = p.xz;
          float r = length(p.xz);
          float k = clamp((uK * 1.25 - r / 220.) / .6, 0., 1.);       // outer edge falls in first
          p.xz = rot2(k * k * 9.) * p.xz;
          p.xz *= 1. - k;
          p.y -= k * k * 40. * (1. - smoothstep(0., 60., r));
          p.y += sin(r * .08 - uT * 2.) * k * 6.;
          vR = k;
          vec4 mv = modelViewMatrix * vec4(p, 1.); vD = -mv.z;
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: /* glsl */ `
        uniform float uFade, uBeat; uniform vec3 uColA; varying vec2 vG; varying float vR; varying float vD;
        void main(){
          vec2 q = vG / 4.; vec2 g = abs(fract(q - .5) - .5) / fwidth(q);
          float l = 1. - min(min(g.x, g.y), 1.);
          float a = l * (1. - vR) * (.6 + uBeat) * uFade;
          gl_FragColor = vec4(uColA * a, 1.);
        }`,
    });
    this.grid = new THREE.Mesh(new THREE.PlaneGeometry(440, 440, 220, 220).rotateX(-Math.PI / 2), this.gridMat);
    this.grid.position.y = -2;
    this.grid.frustumCulled = false;

    // ring of towers that shrink away
    const N = 110;
    const seed = new Float32Array(N * 3);
    this.towers = new THREE.InstancedMesh(makeUnitBox(), this.towerMat, N);
    for (let i = 0; i < N; i++) {
      const a = (i / N) * Math.PI * 2 + r() * 0.1;
      const d = 40 + r() * 90;
      this.towerBase.push({ x: Math.cos(a) * d, z: Math.sin(a) * d, h: 10 + r() * r() * 70, w: 2 + r() * 4 });
      seed.set([r(), r(), r()], i * 3);
    }
    this.towers.instanceColor = new THREE.InstancedBufferAttribute(seed, 3);
    this.towers.frustumCulled = false;
    this.towerMat.uniforms.uFogFar.value = 400;

    // accretion disc
    this.discMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uAmt: { value: 0 }, uColA: { value: new THREE.Color('#00f0ff') }, uColB: { value: new THREE.Color('#39ff88') }, uColC: { value: new THREE.Color('#9b30ff') } },
      transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }`,
      fragmentShader: /* glsl */ `
        uniform float uTime, uAmt; uniform vec3 uColA, uColB, uColC; varying vec2 vUv;
        ${GLSL_COMMON}
        void main(){
          vec2 p = vUv - .5; float r = length(p) * 2.; float a = atan(p.y, p.x);
          float band = smoothstep(.25, .32, r) * (1. - smoothstep(.6, 1., r));
          float sw = fbm(vec3(cos(a + uTime * (1.2 / (r + .2))) * r * 5., sin(a + uTime * (1.2 / (r + .2))) * r * 5., r * 3. - uTime * .4));
          vec3 col = mix(uColB, uColA, smoothstep(.3, .8, r)) * (.4 + sw * 2.);
          col += uColC * smoothstep(.55, .9, sw) * .6;
          float v = band * uAmt * (.4 + sw);
          gl_FragColor = vec4(col * v * 1.6, v);
        }`,
    });
    this.disc = new THREE.Mesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), this.discMat);
    this.disc.frustumCulled = false;
    this.disc.rotation.z = 0.35;
    this.hole.position.set(0, 8, 0);
    this.disc.position.set(0, 8, 0);
    this.halo.points.position.set(0, 8, 0);
    this.logo.points.position.set(0, 0, 8);
    this.group.add(this.grid, this.towers, this.ps.group, this.disc, this.hole, this.halo.points, this.shocks.group, this.logo.points);
    this.fx.vignette = 0.7;
  }

  protected onEnter(f: FrameState): void {
    const s = f.section;
    const loudEnd = this.envProbe.drumsEndAfter(s.start + 1);
    this.tCollapseEnd = loudEnd > s.start ? loudEnd : s.start + (s.end - s.start) * 0.78;
    this.tDark = Math.min(s.end - 0.7, this.tCollapseEnd + 2.4);
    this.tLogo = this.tDark - 1.3;
    this.tEnd = s.end;
    this.logo.setPlain('NEON // VOID', this.tLogo, this.tLogo + 1.6, 1e9, 1e9 + 1, { fontPx: 170, scale: 0.0115, step: 5 });
    this.shocks.clear();
  }

  update(f: FrameState, q: QualitySettings): void {
    const s = f.section;
    const t = f.t;
    const kRaw = (t - s.start) / Math.max(1, this.tCollapseEnd - s.start);
    const k = Math.min(1, Math.max(0, kRaw));
    const collapse = k * k * (3 - 2 * k) * 0.9 + (k > 0.8 ? (k - 0.8) * 0.5 : 0);
    const fade = 1 - smoothstep(this.tCollapseEnd - 0.2, this.tDark, t);
    // NOTE: the fade is applied per element (not to the whole frame) so the logo stays lit.

    // particles: spread wide, then everything spirals in
    const u = this.ps.uniforms;
    u.uRadius.value = 120;
    u.uSink.value = Math.min(1, collapse * 1.08);
    u.uOrigin.value.set(0, 8, 0);
    this.ps.setMix(1, 0, 0);
    this.ps.setDensity(q.particleScale / 1.7, q.trails);
    this.ps.update(f, Math.max(0, fade));

    // grid collapse
    this.gridMat.uniforms.uK.value = collapse;
    this.gridMat.uniforms.uT.value = t;
    this.gridMat.uniforms.uFade.value = fade;
    this.gridMat.uniforms.uBeat.value = Math.exp(-f.sinceBeat * 6) * f.drums;

    // towers shrink + get pulled in
    this.towerMat.uniforms.uCollapse.value = collapse;
    this.towerMat.uniforms.uTime.value = t;
    this.towerMat.uniforms.uFade.value = fade;
    this.towerMat.uniforms.uBeat.value = Math.exp(-f.sinceBeat * 6) * f.drums;
    this.towerMat.uniforms.uKick.value = f.kick;
    const cnt = Math.max(30, Math.floor(110 * Math.min(1, q.instanceScale)));
    this.towers.count = cnt;
    for (let i = 0; i < cnt; i++) {
      const b = this.towerBase[i];
      this.dummy.position.set(b.x, -2, b.z);
      this.dummy.scale.set(b.w, b.h, b.w);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.updateMatrix();
      this.towers.setMatrixAt(i, this.dummy.matrix);
    }
    this.towers.instanceMatrix.needsUpdate = true;

    // the void itself
    const grow = smoothstep(0, 1, k);
    const hs = 1 + grow * 2.2 + f.bassS * 0.3;
    this.hole.scale.setScalar(hs);
    this.disc.scale.setScalar(70 * (0.6 + grow * 0.7));
    this.disc.rotation.y = t * 0.1;
    this.discMat.uniforms.uTime.value = t;
    this.discMat.uniforms.uAmt.value = (0.25 + grow * 0.9 + f.kick * 0.25) * fade;
    this.halo.u.uSize.value = (30 + grow * 40) * (1 + f.kick * 0.25);
    this.halo.u.uAlpha.value = (0.25 + grow * 0.5) * fade;

    // logo: stays at full strength even after the world fades
    this.logo.uniforms.uTime.value = t;
    this.logo.uniforms.uPulse.value = 0.5 + 0.5 * Math.sin(f.real * 2.0);
    this.logo.uniforms.uKeep.value = q.lyricDensity;
    this.logo.uniforms.uSize.value = 0.085;
    this.logo.uniforms.uOpacity.value = 2.4;
    this.shocks.update(f.dt);
    this.fx.glitch = (1 - k) * 0.02 + f.snare * 0.04 * fade;
    this.fx.bloom = 1.1;
  }

  shot(f: FrameState): CameraShot {
    const s = this.shotOut;
    const t = f.t;
    const k = Math.min(1, Math.max(0, (t - f.section.start) / Math.max(1, this.tCollapseEnd - f.section.start)));
    const settle = smoothstep(this.tCollapseEnd, this.tEnd, t);
    const a = f.sectionTime * 0.12;
    const d = 95 - k * 28;
    s.pos.set(Math.sin(a) * d * (1 - settle), 18 - k * 10 + settle * -4, Math.cos(a) * d * (1 - settle) + settle * 20);
    s.target.set(0, 8 * (1 - settle), settle * 8);
    s.fov = 60 - settle * 8;
    s.roll = Math.sin(a) * 0.1 * (1 - settle);
    s.smooth = 2.4;
    s.shake = 0.18 * (1 - settle);
    s.bassFov = 6;
    return s;
  }

  dispose() {
    this.ps.dispose();
    this.grid.geometry.dispose();
    this.gridMat.dispose();
    this.towers.geometry.dispose();
    this.towerMat.dispose();
    this.disc.geometry.dispose();
    this.discMat.dispose();
    this.halo.dispose();
    this.shocks.dispose();
    this.logo.dispose();
  }
}
