import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import type { EventMap, EventType } from '../engine/BeatSystem';
import { ParticleSystem } from '../particles/ParticleSystem';
import { ShockwavePool } from '../effects/Shockwave';
import { Glow } from '../effects/Glow';
import { makeBoxMaterial, makeUnitBox } from '../effects/Materials';
import { GLSL_COMMON } from '../util/glsl';
import { PALETTE } from '../util/shared';
import { rng } from '../util/math';

/**
 * ENERGY CORE — a huge plasma core. It breathes with bass (bigger = louder), pulses on every
 * beat, spins, throws sparks and spherical shockwaves; gyroscope rings are lit by a real
 * point light inside it, debris orbits and is shoved outward by kicks.
 */
export class EnergyCoreScene extends BaseScene {
  readonly id: SceneId = 'core';
  private coreMat: THREE.ShaderMaterial;
  private core: THREE.Mesh;
  private shell: THREE.LineSegments;
  private rings: THREE.Mesh[] = [];
  private light = new THREE.PointLight('#40f4ff', 0, 160, 1.6);
  private halo = new Glow('#5ff6ff');
  private sparks = new ParticleSystem({ count: 140000, size: 0.085, seed: 61 });
  private shocks = new ShockwavePool(10);
  private spheres: THREE.Mesh[] = [];
  private sphereAge: number[] = [];
  private debris: THREE.InstancedMesh;
  private debrisMat = makeBoxMaterial({ edge: 0.08 });
  private debrisBase: THREE.Matrix4[] = [];
  private dummy = new THREE.Object3D();
  private ambient = new THREE.AmbientLight('#0a1a40', 0.5);

  constructor() {
    super();
    this.coreMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 }, uBass: { value: 0 }, uKick: { value: 0 }, uColA: { value: new THREE.Color('#00f0ff') }, uColB: { value: new THREE.Color('#39ff88') }, uColC: { value: new THREE.Color('#9b30ff') }, uMid: { value: 0 } },
      vertexShader: /* glsl */ `
        uniform float uTime, uBass, uKick; varying vec3 vN; varying vec3 vP; varying vec3 vV; varying float vD;
        ${GLSL_COMMON}
        void main(){
          vN = normalize(normalMatrix * normal);
          float n = fbm(position * 1.6 + uTime * .35);
          float disp = (n - .45) * (.35 + uBass * .9) + uKick * .18;
          vec3 p = position + normal * disp;
          vP = position;
          vec4 mv = modelViewMatrix * vec4(p, 1.);
          vV = normalize(-mv.xyz); vD = disp;
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: /* glsl */ `
        uniform float uTime, uBass, uKick, uMid; uniform vec3 uColA, uColB, uColC; varying vec3 vN; varying vec3 vP; varying vec3 vV; varying float vD;
        ${GLSL_COMMON}
        void main(){
          float fr = pow(1. - max(dot(normalize(vN), normalize(vV)), 0.), 2.2);
          float pl = fbm(vP * 2.4 + vec3(0., uTime * .6, uTime * .3));
          float vein = smoothstep(.45, .5, abs(fract(pl * 5.) - .5) + .0) ;
          vec3 col = mix(uColA, uColB, smoothstep(.3, .8, pl)) * (.7 + pl * 1.6);
          col = mix(col, vec3(1.), smoothstep(.62, .95, pl + uKick * .5) * .8);
          col += uColC * smoothstep(.7, .9, hash31(floor(vP * 6.) + floor(uTime * 3.))) * .15;
          col += uColA * fr * (.9 + uBass * 1.1);
          col *= .5 + uKick * .5 + uBass * .25 + vD * .4;
          gl_FragColor = vec4(col, 1.);
        }`,
    });
    this.core = new THREE.Mesh(new THREE.IcosahedronGeometry(10, 5), this.coreMat);
    this.shell = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.IcosahedronGeometry(15, 2)),
      new THREE.LineBasicMaterial({ color: PALETTE.cyan, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false }),
    );

    // gyroscope rings (physically lit by the core's point light)
    const ringMat = new THREE.MeshStandardMaterial({ color: '#0a1830', metalness: 0.9, roughness: 0.28, emissive: '#00323a', emissiveIntensity: 0.6 });
    [24, 31, 39].forEach((R, i) => {
      const m = new THREE.Mesh(new THREE.TorusGeometry(R, 0.55 + i * 0.12, 16, 200), ringMat);
      m.userData.axis = new THREE.Vector3(Math.sin(i * 2 + 1), Math.cos(i * 1.3), Math.sin(i * 0.7 + 2)).normalize();
      m.userData.speed = 0.25 + i * 0.12;
      m.rotation.set(i * 1.1, i * 0.6, 0);
      this.rings.push(m);
      this.group.add(m);
    });

    // debris
    const r = rng(8080);
    const N = 340;
    const seed = new Float32Array(N * 3);
    this.debris = new THREE.InstancedMesh(makeUnitBox(), this.debrisMat, N);
    for (let i = 0; i < N; i++) {
      const m = new THREE.Matrix4();
      const a = r() * Math.PI * 2, e = (r() - 0.5) * 1.6, d = 46 + r() * 70;
      m.compose(
        new THREE.Vector3(Math.cos(a) * Math.cos(e) * d, Math.sin(e) * d, Math.sin(a) * Math.cos(e) * d),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(r() * 6, r() * 6, r() * 6)),
        new THREE.Vector3(0.8 + r() * 2.4, 0.8 + r() * 2.4, 0.8 + r() * 2.4),
      );
      this.debrisBase.push(m);
      this.debris.setMatrixAt(i, m);
      seed.set([r(), r(), r()], i * 3);
    }
    this.debris.instanceColor = new THREE.InstancedBufferAttribute(seed, 3);
    this.debris.frustumCulled = false;
    this.debrisMat.uniforms.uFogFar.value = 400;

    // spherical shockwave shells
    const sg = new THREE.SphereGeometry(1, 40, 20);
    for (let i = 0; i < 4; i++) {
      const m = new THREE.Mesh(sg, new THREE.ShaderMaterial({
        uniforms: { uA: { value: 0 }, uCol: { value: new THREE.Color('#00f0ff') } },
        transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
        vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position, 1.); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
        fragmentShader: `uniform float uA; uniform vec3 uCol; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1. - abs(dot(normalize(vN), normalize(vV))), 2.5); gl_FragColor = vec4(uCol * f * uA, f * uA); }`,
      }));
      m.visible = false;
      this.spheres.push(m);
      this.sphereAge.push(9);
      this.group.add(m);
    }
    this.group.add(this.core, this.shell, this.light, this.ambient, this.sparks.group, this.shocks.group, this.debris, this.halo.points);
    this.fx.ca = 0.0024;
    this.fx.bloom = 0.85;
  }

  protected onEnter(): void {
    const big = this.variant === 1;
    const a = PALETTE.cyan, b = big ? PALETTE.white : PALETTE.green;
    this.coreMat.uniforms.uColA.value.copy(a);
    this.coreMat.uniforms.uColB.value.copy(b);
    this.sparks.uniforms.uColA.value.copy(a);
    this.sparks.uniforms.uColB.value.copy(big ? PALETTE.green : PALETTE.deepBlue);
    this.debrisMat.uniforms.uColA.value.copy(a);
    this.debrisMat.uniforms.uColB.value.copy(PALETTE.green);
    this.flashColor.copy(big ? PALETTE.white : PALETTE.cyan);
    this.shocks.clear();
    this.sphereAge.fill(9);
    this.spheres.forEach((s) => (s.visible = false));
  }

  update(f: FrameState, q: QualitySettings): void {
    const big = this.variant === 1;
    const bass = f.bassS;
    const scale = 1 + bass * (big ? 1.0 : 0.8) + f.kick * 0.28 + f.energy * 0.25;
    this.core.scale.setScalar(scale);
    this.core.rotation.y += f.dt * (0.2 + f.mid * 0.8);
    this.core.rotation.x += f.dt * 0.07;
    this.coreMat.uniforms.uTime.value = f.t;
    this.coreMat.uniforms.uBass.value = bass;
    this.coreMat.uniforms.uKick.value = f.kick;
    this.coreMat.uniforms.uMid.value = f.mid;
    this.shell.scale.setScalar(scale * (1.02 + f.kick * 0.06));
    this.shell.rotation.y -= f.dt * 0.12;
    this.shell.rotation.z += f.dt * 0.05;
    (this.shell.material as THREE.LineBasicMaterial).opacity = 0.25 + f.mid * 0.5;

    this.rings.forEach((m) => {
      m.rotateOnAxis(m.userData.axis, f.dt * m.userData.speed * (1 + f.mid * 2.2 + f.kick));
      m.scale.setScalar(1 + bass * 0.12);
    });
    this.light.intensity = q.dynamicLights ? 900 * (0.3 + bass * 1.4 + f.kick) : 0;
    this.light.visible = q.dynamicLights;
    this.halo.u.uSize.value = 34 * scale;
    this.halo.u.uAlpha.value = 0.1 + f.rms * 0.22 + f.kick * 0.1;

    // sparks radiate from the core: continuous burst field (phase restarts on downbeat)
    const u = this.sparks.uniforms;
    this.sparks.setMix(0.25, 0, 1);
    u.uBurstR.value = 80 + bass * 70 + (big ? 30 : 0);
    u.uRadius.value = 30;
    this.sparks.setDensity(q.particleScale / 1.7, q.trails);
    this.sparks.update(f, 0.22 + f.rms * 0.4);

    // debris orbit; kicks shove it outward
    const orbit = f.t * (0.05 + f.mid * 0.0);
    const push = 1 + f.kick * 0.1 + bass * 0.12;
    const cnt = Math.max(60, Math.floor(340 * Math.min(1, q.instanceScale)));
    this.debris.count = cnt;
    const rotQ = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0.2, 1, 0.1).normalize(), orbit);
    const m = new THREE.Matrix4();
    for (let i = 0; i < cnt; i++) {
      m.copy(this.debrisBase[i]);
      this.dummy.matrix.copy(m).decompose(this.dummy.position, this.dummy.quaternion, this.dummy.scale);
      this.dummy.position.applyQuaternion(rotQ).multiplyScalar(push);
      this.dummy.rotation.x += f.t * 0.3 * (i % 3);
      this.dummy.updateMatrix();
      this.debris.setMatrixAt(i, this.dummy.matrix);
    }
    this.debris.instanceMatrix.needsUpdate = true;
    this.debrisMat.uniforms.uTime.value = f.t;
    this.debrisMat.uniforms.uBeat.value = Math.exp(-f.sinceBeat * 6);
    this.debrisMat.uniforms.uGlow.value = 0.8 + f.energy;

    // shells
    this.spheres.forEach((s, i) => {
      this.sphereAge[i] += f.dt;
      const k = this.sphereAge[i] / 1.1;
      s.visible = k < 1;
      if (k < 1) {
        s.scale.setScalar(12 + k * 130);
        (s.material as THREE.ShaderMaterial).uniforms.uA.value = (1 - k) * 0.9;
      }
    });
    this.shocks.update(f.dt);
    this.fx.glitch = f.snare * 0.05;
    this.fx.distort = bass * 0.03;
  }

  onEvent<K extends EventType>(type: K, _e: EventMap[K], f: FrameState): void {
    if (type === 'beat' && f.drums > 0.15) {
      const i = this.sphereAge.indexOf(Math.max(...this.sphereAge));
      this.sphereAge[i] = 0;
      (this.spheres[i].material as THREE.ShaderMaterial).uniforms.uCol.value.copy(f.beatInBar === 0 ? PALETTE.green : PALETTE.cyan);
    }
    if (type === 'downbeat') {
      for (const n of [new THREE.Vector3(0, 1, 0), new THREE.Vector3(1, 0, 0.3), new THREE.Vector3(0.2, 0.3, 1)])
        this.shocks.spawn(new THREE.Vector3(), PALETTE.cyan, 110, 1.6, n, 0.8, 0.035);
    }
  }

  shot(f: FrameState): CameraShot {
    const s = this.shotOut;
    const t = f.sectionTime;
    const big = this.variant === 1;
    const a = t * (big ? 0.32 : 0.22);
    const dist = (big ? 70 : 82) - f.bassS * 8 + Math.sin(t * 0.3) * 6 - f.sectionProgress * 10;
    s.pos.set(Math.sin(a) * dist, Math.sin(t * 0.17) * 18 + 6, Math.cos(a) * dist);
    s.target.set(0, 0, 0);
    s.fov = big ? 62 : 58;
    s.roll = Math.sin(t * 0.2) * 0.08;
    s.smooth = 2.6;
    s.shake = 0.35;
    s.bassFov = 7;
    return s;
  }

  dispose() {
    this.core.geometry.dispose();
    this.coreMat.dispose();
    this.sparks.dispose();
    this.shocks.dispose();
    this.halo.dispose();
    this.debris.geometry.dispose();
    this.debrisMat.dispose();
  }
}
