import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import type { EventMap, EventType } from '../engine/BeatSystem';
import { ParticleSystem } from '../particles/ParticleSystem';
import { ShockwavePool } from '../effects/Shockwave';
import { makeBoxMaterial, makeUnitBox } from '../effects/Materials';
import { PALETTE } from '../util/shared';
import { rng } from '../util/math';

const RING_COUNT = 9;

/**
 * DIGITAL VOID — a vast dark space: breathing giant rings, distant monoliths and wire
 * polyhedra, volumetric-looking light shafts, drifting dust. Bass breathes the world,
 * downbeats send shockwaves across it.
 */
export class VoidScene extends BaseScene {
  readonly id: SceneId = 'void';
  private dust = new ParticleSystem({ count: 90000, size: 0.14, seed: 21 });
  private shocks = new ShockwavePool(8);
  private rings: THREE.Mesh[] = [];
  private ringMats: THREE.MeshBasicMaterial[] = [];
  private polys: THREE.LineSegments[] = [];
  private mono: THREE.InstancedMesh;
  private monoMat = makeBoxMaterial({ edge: 0.12 });
  private beams = new THREE.Group();
  private beamMats: THREE.ShaderMaterial[] = [];
  private pos = new THREE.Vector3();
  private fwd = new THREE.Vector3();

  constructor() {
    super();
    const r = rng(5);
    this.group.add(this.dust.group, this.shocks.group, this.beams);

    // giant rings
    const tor = new THREE.TorusGeometry(1, 0.0055, 8, 220);
    for (let i = 0; i < RING_COUNT; i++) {
      const m = new THREE.MeshBasicMaterial({ color: PALETTE.cyan, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
      const mesh = new THREE.Mesh(tor, m);
      mesh.position.set(Math.sin(i * 2.1) * 4, Math.cos(i * 1.7) * 3, 40 - i * 32);
      mesh.userData.r = 22 + (i % 3) * 7 + r() * 5;
      mesh.userData.spin = (r() - 0.5) * 0.25;
      mesh.rotation.set((r() - 0.5) * 0.25, (r() - 0.5) * 0.25, r() * 6);
      this.rings.push(mesh);
      this.ringMats.push(m);
      this.group.add(mesh);
    }

    // distant wire polyhedra
    const geos = [new THREE.IcosahedronGeometry(1, 1), new THREE.OctahedronGeometry(1, 0), new THREE.DodecahedronGeometry(1, 0)];
    for (let i = 0; i < 7; i++) {
      const e = new THREE.LineSegments(
        new THREE.EdgesGeometry(geos[i % 3]),
        new THREE.LineBasicMaterial({ color: i % 3 === 2 ? PALETTE.purple : PALETTE.deepBlue, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }),
      );
      const ang = i * 0.9 + 0.5;
      e.position.set(Math.cos(ang) * (60 + r() * 40), (r() - 0.5) * 50, -20 - i * 38);
      e.scale.setScalar(8 + r() * 14);
      this.polys.push(e);
      this.group.add(e);
    }

    // monoliths
    const box = makeUnitBox();
    this.mono = new THREE.InstancedMesh(box, this.monoMat, 36);
    const m4 = new THREE.Matrix4();
    const seed = new Float32Array(36 * 3);
    for (let i = 0; i < 36; i++) {
      const a = r() * Math.PI * 2;
      const d = 55 + r() * 70;
      const h = 30 + r() * 110;
      m4.compose(
        new THREE.Vector3(Math.cos(a) * d, -h * 0.35, 30 - r() * 330),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(0, r() * 3, (r() - 0.5) * 0.1)),
        new THREE.Vector3(2 + r() * 4, h, 2 + r() * 4),
      );
      this.mono.setMatrixAt(i, m4);
      seed.set([r(), r(), r()], i * 3);
    }
    this.mono.instanceColor = new THREE.InstancedBufferAttribute(seed, 3);
    this.mono.frustumCulled = false;
    this.monoMat.uniforms.uFogFar.value = 330;
    this.group.add(this.mono);

    // light shafts
    const cyl = new THREE.CylinderGeometry(0.4, 9, 190, 28, 1, true);
    cyl.translate(0, -95, 0);
    for (let i = 0; i < 6; i++) {
      const mat = new THREE.ShaderMaterial({
        uniforms: { uCol: { value: new THREE.Color(i % 3 === 2 ? '#9b30ff' : '#00bfff') }, uI: { value: 0.2 } },
        transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
        vertexShader: `varying vec3 vN; varying vec3 vV; varying float vY;
          void main(){ vY = -position.y / 190.; vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position, 1.); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
        fragmentShader: `uniform vec3 uCol; uniform float uI; varying vec3 vN; varying vec3 vV; varying float vY;
          void main(){ float c = pow(abs(dot(normalize(vN), normalize(vV))), 2.2); float a = c * (1. - vY) * (1. - vY) * uI; gl_FragColor = vec4(uCol * a, a); }`,
      });
      const m = new THREE.Mesh(cyl, mat);
      m.position.set((i - 2.5) * 22, 70, -30 - i * 25);
      m.userData.phase = r() * 6;
      this.beamMats.push(mat);
      this.beams.add(m);
    }
    this.fx.vignette = 0.6;
  }

  protected onEnter(): void {
    this.shocks.clear();
    const hush = this.variant === 1;
    const c = hush ? PALETTE.purple : PALETTE.cyan;
    this.ringMats.forEach((m, i) => m.color.copy(i % 4 === 3 ? PALETTE.green : c));
    this.dust.uniforms.uColA.value.copy(hush ? new THREE.Color('#7a3cff') : PALETTE.cyan);
    this.dust.uniforms.uColB.value.copy(hush ? new THREE.Color('#2a1a8a') : PALETTE.deepBlue);
    this.monoMat.uniforms.uColA.value.copy(hush ? PALETTE.purple : PALETTE.cyan);
    this.flashColor.copy(hush ? PALETTE.purple : PALETTE.cyan);
  }

  update(f: FrameState, q: QualitySettings): void {
    const bass = f.bassS;
    const hush = this.variant === 1;
    this.dust.setDensity(q.particleScale / 1.7 * 0.9, q.trails > 0 ? 1 : 0);
    this.dust.setMix(1, 0, 0);
    this.dust.uniforms.uRadius.value = 70;
    this.dust.uniforms.uSize.value = 0.15;
    this.dust.update(f, hush ? 0.55 : 0.9);

    // rings breathe with bass, flash on the kick
    this.rings.forEach((m, i) => {
      const k = 1 + bass * 0.18 + f.kick * 0.05;
      m.scale.setScalar(m.userData.r * k);
      m.rotation.z += m.userData.spin * f.dt * (1 + f.mid * 2);
      this.ringMats[i].opacity = (hush ? 0.35 : 0.5) + f.kick * 0.5 + bass * 0.25;
    });
    this.polys.forEach((p, i) => {
      p.rotation.y += f.dt * (0.08 + i * 0.015) * (1 + f.mid);
      p.rotation.x += f.dt * 0.05;
      (p.material as THREE.LineBasicMaterial).opacity = 0.35 + f.mid * 0.5 + f.kick * 0.2;
    });
    this.monoMat.uniforms.uTime.value = f.t;
    this.monoMat.uniforms.uBeat.value = Math.exp(-f.sinceBeat * 6) * (0.25 + f.drums);
    this.monoMat.uniforms.uKick.value = f.kick;
    this.monoMat.uniforms.uBass.value = bass;
    this.monoMat.uniforms.uGlow.value = 0.7 + f.energy * 0.8;

    this.beams.rotation.y = f.t * 0.05;
    this.beamMats.forEach((m, i) => {
      m.uniforms.uI.value = (hush ? 0.12 : 0.2) + f.low * 0.35 + f.kick * 0.25 + 0.05 * Math.sin(f.t * 0.8 + i);
    });
    this.shocks.update(f.dt);
  }

  onEvent<K extends EventType>(type: K, _e: EventMap[K], f: FrameState): void {
    if (type === 'downbeat') {
      this.fwd.copy(this.shotOut.target).sub(this.shotOut.pos).normalize();
      this.pos.copy(this.shotOut.pos).addScaledVector(this.fwd, 36);
      this.shocks.spawn(this.pos, this.variant ? PALETTE.purple : PALETTE.cyan, 55, 1.7, this.fwd, 0.9, 0.05);
    }
    void f;
  }

  shot(f: FrameState): CameraShot {
    const s = this.shotOut;
    const sT = f.sectionTime;
    const speed = this.variant === 1 ? 1.2 : 4.4;
    const z = 74 - sT * speed;
    const a = sT * 0.16;
    s.pos.set(Math.sin(a) * 14, 5 + Math.sin(sT * 0.21) * 4 + f.bassS * 1.2, z);
    s.target.set(Math.sin(a + 0.8) * 5, 1 + Math.sin(sT * 0.13) * 2, z - 45);
    s.fov = 58;
    s.roll = Math.sin(sT * 0.12) * 0.06;
    s.smooth = 2.2;
    s.shake = 0.07;
    s.bassFov = 5;
    return s;
  }

  dispose() {
    this.dust.dispose();
    this.shocks.dispose();
    this.monoMat.dispose();
    this.mono.geometry.dispose();
  }
}
