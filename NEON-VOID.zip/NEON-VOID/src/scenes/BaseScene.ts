import * as THREE from 'three';
import type { FrameState } from '../engine/FrameState';
import type { EventMap, EventType } from '../engine/BeatSystem';
import type { QualitySettings } from '../types';
import type { FxParams } from '../effects/PostFX';
import { makeShot, type CameraShot } from '../camera/CameraController';

export type SceneId = 'intro' | 'void' | 'grid' | 'storm' | 'city' | 'glitch' | 'core' | 'final';

/** Base class of every world. A scene owns a Group; only the active scene is visible. */
export abstract class BaseScene {
  abstract readonly id: SceneId;
  readonly group = new THREE.Group();
  /** Baseline post-processing a scene asks for. */
  readonly fx: FxParams = { glitch: 0, ca: 0.0012, distort: 0, bloom: 1, vignette: 0.55 };
  /** Master fade (0..1) that FinalScene drives; applied by the engine to PostFX. */
  fade = 1;
  variant = 0;
  protected readonly shotOut: CameraShot = makeShot();
  /** Colour used for the screen flash on transitions. */
  flashColor = new THREE.Color('#9ff8ff');

  constructor() {
    this.group.visible = false;
  }

  enter(variant: number, f: FrameState): void {
    this.variant = variant;
    this.group.visible = true;
    this.fade = 1;
    this.onEnter(f);
  }
  exit(): void {
    this.group.visible = false;
  }
  reset(f: FrameState) {
    this.onEnter(f);
  }

  protected onEnter(_f: FrameState): void {}
  abstract update(f: FrameState, q: QualitySettings): void;
  /** Fill `this.shotOut` and return it. */
  abstract shot(f: FrameState): CameraShot;
  onEvent<K extends EventType>(_type: K, _e: EventMap[K], _f: FrameState): void {}
  abstract dispose(): void;
}
