import * as THREE from 'three';
import { BaseScene, type SceneId } from './BaseScene';
import type { FrameState } from '../engine/FrameState';
import type { QualitySettings } from '../types';
import type { CameraShot } from '../camera/CameraController';
import type { EventMap, EventType } from '../engine/BeatSystem';
import { ParticleSystem } from '../particles/ParticleSystem';
import { ShockwavePool } from '../effects/Shockwave';
import { Glow } from '../effects/Glow';
import { PALETTE } from '../util/shared';
import { damp, lerp } from '../util/math';

/**
 * PARTICLE STORM — one analytic particle field morphing through four physical regimes, one
 * per bar:  TUNNEL (streaming helix) -> VORTEX (tight, fast spin) -> IMPLOSION (spiral into the
 * eye) -> EXPLOSION (radial burst on the downbeat). Energy comes from RMS, bass swells the
 * radius, kicks push it, section time sets the tempo of the whole thing.
 */
const PATTERNS = [
  // dust, tunnel, burst, sinkTarget, radius, twist, spin
  { mix: [0.1, 1, 0], sink: 0, tr: 15, twist: 3, spin: 1.1 },   // tunnel
  { mix: [0.05, 1, 0], sink: 0, tr: 8, twist: 9, spin: 2.4 },    // vortex
  { mix: [1, 0, 0], sink: 0.92, tr: 15, twist: 3, spin: 1.1 },   // implosion
  { mix: [0.15, 0, 1], sink: 0, tr: 15, twist: 3, spin: 1.1 },   // explosion
];

export class ParticleStormScene extends BaseScene {
  readonly id: SceneId = 'storm';
  private ps = new ParticleSystem({ count: 140000, size: 0.085, seed: 41 });
  private shocks = new ShockwavePool(8);
  private eye = new THREE.Mesh(new THREE.SphereGeometry(4.5, 32, 16), new THREE.MeshBasicMaterial({ color: 0x000000 }));
  private halo = new Glow('#7ff4ff');
  private mix = new THREE.Vector3(0.1, 1, 0);
  private sink = 0;
  private tr = 15;
  private twist = 3;
  private spin = 1;
  private lastBar = -1;

  constructor() {
    super();
    this.eye.position.set(0, 0, -105);
    this.halo.points.position.set(0, 0, -106);
    this.group.add(this.ps.group, this.eye, this.halo.points, this.shocks.group);
    this.fx.ca = 0.002;
    this.fx.distort = 0.02;
  }

  protected onEnter(): void {
    const calm = this.variant === 1;
    this.ps.uniforms.uColA.value.copy(calm ? PALETTE.purple : PALETTE.cyan);
    this.ps.uniforms.uColB.value.copy(calm ? PALETTE.cyan : PALETTE.deepBlue);
    this.ps.uniforms.uColC.value.copy(calm ? PALETTE.green : PALETTE.purple);
    this.flashColor.copy(calm ? PALETTE.purple : PALETTE.cyan);
    this.shocks.clear();
    this.sink = 0;
    this.lastBar = -1;
  }

  update(f: FrameState, q: QualitySettings): void {
    const calm = this.variant === 1;
    // Chorus 3 is the quiet one: first half drifts (implosion/vortex), second half builds.
    const pi = f.barInSection % 4;
    const pat = calm && f.sectionProgress < 0.5 ? PATTERNS[pi % 2 === 0 ? 1 : 2] : PATTERNS[pi];
    const d = f.dt;
    this.mix.x = damp(this.mix.x, pat.mix[0], 6, d);
    this.mix.y = damp(this.mix.y, pat.mix[1], 6, d);
    this.mix.z = damp(this.mix.z, pat.mix[2], 14, d);
    this.tr = damp(this.tr, pat.tr, 4, d);
    this.twist = damp(this.twist, pat.twist, 3, d);
    this.spin = damp(this.spin, pat.spin, 3, d);
    // implosion ramps through the bar and snaps back (that snap IS the explosion's origin)
    if (pat.sink > 0) this.sink = damp(this.sink, pat.sink * (0.35 + 0.65 * f.barPhase), 5, d);
    else this.sink = damp(this.sink, 0, 30, d);

    const u = this.ps.uniforms;
    const energy = (calm ? 0.35 : 0.6) + f.rms * 0.9;
    u.uSpeed.value = lerp(14, 60, f.energy) * (calm ? 0.6 : 1) + f.kick * 8;
    u.uSpin.value = this.spin * (0.7 + f.mid * 1.4);
    u.uTunnelR.value = this.tr;
    u.uTwist.value = this.twist;
    u.uTunnelLen.value = 110;
    u.uRadius.value = 34 + f.bassS * 8;
    u.uBurstR.value = 70 + f.bassS * 25;
    u.uSink.value = this.sink;
    u.uSize.value = 0.085 * (calm ? 0.9 : 1);
    this.ps.setMix(this.mix.x, this.mix.y, this.mix.z);
    this.ps.setDensity(q.particleScale / 1.7, q.trails);
    this.ps.update(f, Math.min(1, energy));

    // the eye pulses with bass
    const sc = 1 + f.bassS * 0.5 + f.kick * 0.2;
    this.eye.scale.setScalar(sc);
    this.halo.u.uSize.value = 26 * sc * (1 + f.kick * 0.4);
    this.halo.u.uAlpha.value = 0.35 + f.rms * 0.6;
    this.shocks.update(f.dt);
    this.fx.glitch = f.snare * 0.07;
    this.fx.bloom = 1.05 + f.rms * 0.3;

    if (f.barIndex !== this.lastBar) this.lastBar = f.barIndex;
  }

  onEvent<K extends EventType>(type: K, e: EventMap[K], f: FrameState): void {
    if (type === 'kick') {
      const s = (e as EventMap['kick']).strength;
      this.shocks.spawn(new THREE.Vector3(0, 0, -45), PALETTE.cyan, 34, 0.9, new THREE.Vector3(0, 0, 1), 0.55 * s, 0.05);
    }
    if (type === 'downbeat') {
      this.shocks.spawn(new THREE.Vector3(0, 0, -20), PALETTE.green, 60, 1.4, new THREE.Vector3(0, 0, 1), 0.8, 0.04);
    }
    void f;
  }

  shot(f: FrameState): CameraShot {
    const s = this.shotOut;
    const t = f.sectionTime;
    const calm = this.variant === 1;
    // pull back a little on the explosion bar, push in on implosion
    const pat = f.barInSection % 4;
    const dz = pat === 3 ? 3 * f.kick : pat === 2 ? -2 * f.barPhase : 0;
    s.pos.set(Math.sin(t * 0.4) * 2.4, Math.cos(t * 0.31) * 1.6, 9 + dz);
    s.target.set(0, 0, -40);
    s.fov = calm ? 58 : 64;
    s.roll = Math.sin(t * 0.25) * 0.25 * (calm ? 0.6 : 1) + (pat === 1 ? 0.2 : 0);
    s.smooth = 3.5;
    s.shake = 0.14;
    s.bassFov = 9;
    return s;
  }

  dispose() {
    this.ps.dispose();
    this.shocks.dispose();
    this.halo.dispose();
    this.eye.geometry.dispose();
  }
}
