/**
 * Types mirror the REAL structure of data/audio.json and data/lyrics.json
 * (verified against the supplied files, see README "Data format").
 *
 * audio.json  (all times in seconds on the gapless-MP3 timeline)
 *   duration, bpm, beat_period, time_signature
 *   beats[]        number[]  (every beat, constant tempo)
 *   downbeats[]    number[]  (every bar start)
 *   sections[]     {name,start,end}
 *   fps            envelope sample rate (100)
 *   rms/low/mid/high/vocal/drums/bass/other[]   0..1 envelopes, frame i centred at i/fps
 *   onsets.{kick,snare,hat,vocal}[]             [time, strength 0..1] pairs
 *
 * lyrics.json
 *   lines[]  {i,text,start,end,words[{w,start,end,conf,syl?[[s,e],..]}]}
 *   extras[] {start,end,desc}  (ad-lib / backing-vocal regions, no text)
 */

export type EnvName = 'rms' | 'low' | 'mid' | 'high' | 'vocal' | 'drums' | 'bass' | 'other';
export type OnsetName = 'kick' | 'snare' | 'hat' | 'vocal';

export interface Section {
  name: string;
  start: number;
  end: number;
}

export interface OnsetTrack {
  times: Float64Array;
  strengths: Float32Array;
}

/** audio.json after validation and conversion to typed arrays. */
export interface AudioData {
  duration: number;
  bpm: number;
  beatPeriod: number;
  timeSignature: number;
  beats: Float64Array;
  downbeats: Float64Array;
  sections: Section[];
  fps: number;
  env: Record<EnvName, Float32Array>;
  onsets: Record<OnsetName, OnsetTrack>;
}

export interface LyricWord {
  w: string;
  start: number;
  end: number;
  conf: number;
  syl?: [number, number][];
}
export interface LyricLine {
  i: number;
  text: string;
  start: number;
  end: number;
  words: LyricWord[];
}
export interface LyricExtra {
  start: number;
  end: number;
  desc: string;
}
export interface LyricsData {
  lines: LyricLine[];
  extras: LyricExtra[];
}

export interface QualitySettings {
  name: 'LOW' | 'MEDIUM' | 'HIGH' | 'ULTRA';
  /** Upper bound for devicePixelRatio. */
  pixelRatioCap: number;
  /** Multiplies every scene's particle count. */
  particleScale: number;
  /** Number of ghost layers per particle system (motion trails). */
  trails: number;
  bloom: boolean;
  bloomStrength: number;
  bloomRadius: number;
  /** Bloom is rendered at this fraction of the frame resolution. */
  bloomResolution: number;
  /** 0..1 richness of the final pass (grain, scanlines, chromatic aberration, glitch). */
  post: number;
  /** Multiplies city / debris / pillar instance counts. */
  instanceScale: number;
  /** Fraction of sampled lyric particles kept. */
  lyricDensity: number;
  /** Real PointLights on lit materials. */
  dynamicLights: boolean;
}
