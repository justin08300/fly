import * as THREE from 'three';
import { damp } from '../util/math';
import type { FrameState } from '../engine/FrameState';

/** What a scene asks of the camera each frame. The controller smooths + decorates it. */
export interface CameraShot {
  pos: THREE.Vector3;
  target: THREE.Vector3;
  fov: number;
  roll: number;
  /** Follow speed (1/s). Higher = tighter. */
  smooth: number;
  /** Peak kick shake in world units. */
  shake: number;
  /** FOV added at full bass. */
  bassFov: number;
}

export function makeShot(): CameraShot {
  return { pos: new THREE.Vector3(0, 0, 10), target: new THREE.Vector3(), fov: 60, roll: 0, smooth: 5, shake: 0.05, bassFov: 4 };
}

export class CameraController {
  private pos = new THREE.Vector3(0, 0, 10);
  private tgt = new THREE.Vector3();
  private fov = 60;
  private roll = 0;
  private whipFov = 0;
  private whipRoll = 0;
  private snapNext = true;
  /** Normalised pointer position (-1..1) for subtle parallax. */
  pointer = new THREE.Vector2();
  private pSmooth = new THREE.Vector2();

  constructor(readonly camera: THREE.PerspectiveCamera) {}

  snap() {
    this.snapNext = true;
  }
  whip(strength = 1) {
    this.whipFov = 22 * strength;
    this.whipRoll = (Math.random() < 0.5 ? -1 : 1) * 0.12 * strength;
  }

  update(shot: CameraShot, f: FrameState, dt: number, shakeScale: number) {
    const d = Math.min(dt, 0.1);
    if (this.snapNext) {
      this.pos.copy(shot.pos);
      this.tgt.copy(shot.target);
      this.fov = shot.fov;
      this.roll = shot.roll;
      this.snapNext = false;
    } else {
      const k = 1 - Math.exp(-shot.smooth * d);
      this.pos.lerp(shot.pos, k);
      this.tgt.lerp(shot.target, k);
      this.fov = damp(this.fov, shot.fov, shot.smooth, d);
      this.roll = damp(this.roll, shot.roll, shot.smooth, d);
    }
    this.whipFov = damp(this.whipFov, 0, 4.5, d);
    this.whipRoll = damp(this.whipRoll, 0, 4, d);
    this.pSmooth.lerp(this.pointer, 1 - Math.exp(-3 * d));

    const cam = this.camera;
    cam.position.copy(this.pos);
    // smooth, kick-driven shake: sum of incommensurate sines (never random jitter)
    const s = f.kick * f.kick * shot.shake * shakeScale;
    if (s > 1e-4) {
      const t = f.real;
      cam.position.x += (Math.sin(t * 61.3) + Math.sin(t * 37.1)) * 0.5 * s;
      cam.position.y += (Math.sin(t * 53.7 + 1.3) + Math.sin(t * 29.9)) * 0.5 * s;
    }
    cam.lookAt(this.tgt);
    // pointer parallax: a tiny lateral shift in camera space
    cam.translateX(this.pSmooth.x * 0.35);
    cam.translateY(this.pSmooth.y * 0.2);
    cam.rotateZ(this.roll + this.whipRoll);
    const fov = this.fov + this.whipFov + f.bassS * shot.bassFov + f.kick * 1.2;
    if (Math.abs(cam.fov - fov) > 1e-3) {
      cam.fov = fov;
      cam.updateProjectionMatrix();
    }
  }
}
