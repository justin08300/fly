import * as THREE from 'three';

/** Uniform objects shared by every point-sprite material. */
export const Shared = {
  /** pixels per world-unit at depth 1 (drawingBufferHeight / (2 tan(fov/2))). */
  pointScale: { value: 800 } as { value: number },
};

export const PALETTE = {
  black: new THREE.Color('#000004'),
  deepBlue: new THREE.Color('#0a2cff'),
  navy: new THREE.Color('#031040'),
  cyan: new THREE.Color('#00f0ff'),
  green: new THREE.Color('#39ff88'),
  purple: new THREE.Color('#9b30ff'),
  white: new THREE.Color('#e8ffff'),
};
