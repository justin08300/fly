import * as THREE from 'three';
import { Shared } from '../util/shared';
import { GLSL_COMMON } from '../util/glsl';
import { rng } from '../util/math';
import type { FrameState } from '../engine/FrameState';

/**
 * GPU particle field. Every particle's position is an analytic function of (seed, time,
 * music uniforms), evaluated in the vertex shader — so 100k+ particles cost almost nothing
 * on the CPU, motion is perfectly seek-safe, and "trails" are just ghost copies of the same
 * function evaluated a few milliseconds in the past.
 *
 * Four motion fields are blended by `mix`:
 *   x  DUST    drifting noise-cloud that breathes with bass
 *   y  TUNNEL  helical vortex streaming toward the camera (speed / twist / spin)
 *   z  BURST   radial explosion that restarts on every downbeat (uBurstT)
 *   sink       attraction: everything spirals into the centre with rising angular speed
 */
const VERT = /* glsl */ `
  attribute vec4 aSeed;
  uniform float uTime, uLag, uSize, uBass, uKick, uRms, uHigh, uBurstT, uSink, uOpacity, uPointScale;
  uniform float uSpeed, uSpin, uRadius, uTunnelR, uTunnelLen, uTwist, uBurstR;
  uniform vec4 uMix;
  uniform vec3 uColA, uColB, uColC, uOrigin;
  uniform float uKeep;
  varying vec3 vCol;
  varying float vA;
  ${GLSL_COMMON}

  void main(){
    vec4 s = aSeed;
    float T = uTime - uLag;
    float u = s.x * 2. - 1.; float a0 = s.y * 6.2831853; float rr = sqrt(1. - u * u);
    vec3 dir = vec3(rr * cos(a0), u, rr * sin(a0));
    float rad = pow(s.z, .55);

    // DUST
    vec3 pd = dir * (uRadius * (.2 + rad * .95));
    float tt = T * .15;
    pd += vec3(sin(tt * 3.1 + s.w * 40. + pd.y * .2), sin(tt * 2.3 + s.z * 30. + pd.z * .2), sin(tt * 2.9 + s.x * 50. + pd.x * .2)) * (1.5 + uRms * 2.);
    pd *= 1. + uBass * .22 * (.4 + s.w);

    // TUNNEL / VORTEX
    float zf = fract(s.x + T * uSpeed / uTunnelLen);
    float tr = uTunnelR * (.3 + .7 * s.y) * (1. + uBass * .3 + uKick * .18);
    float ang = s.z * 6.2831853 + T * uSpin / (.35 + tr / uTunnelR) + zf * uTwist;
    vec3 pt = vec3(cos(ang) * tr, sin(ang) * tr, -uTunnelLen * (1. - zf) + 3.);
    float tunnelFade = smoothstep(0., .06, zf) * (1. - smoothstep(.93, 1., zf));

    // BURST
    float bt = max(uBurstT + (uTime - T) * -1. - s.w * .12, 0.);
    float ease = 1. - exp(-bt * 3.4);
    vec3 pb = dir * uBurstR * (.06 + rad) * ease * (.35 + .65 * s.y);
    pb.xz = rot2(bt * .9 * (.6 + s.z)) * pb.xz;
    float burstFade = 1. - smoothstep(.55, 1., ease) * .55;

    vec3 p = pd * uMix.x + pt * uMix.y + pb * uMix.z;
    float fade = mix(1., tunnelFade, uMix.y) * mix(1., burstFade, uMix.z);

    // SINK (attraction): staggered, spins faster as it falls inward, vanishes at the core.
    float kS = clamp((uSink - s.w * .4) / .6, 0., 1.);
    p.xz = rot2(kS * kS * 16. * (.5 + s.y)) * p.xz;
    p *= pow(1. - kS, 2.2);
    fade *= 1. - smoothstep(.82, 1., kS);

    p += uOrigin;
    vec4 mv = modelViewMatrix * vec4(p, 1.);
    gl_Position = projectionMatrix * mv;

    float tw = .5 + .5 * sin(T * 9. + s.z * 80.);
    float bright = .32 + uRms * .45 + uKick * .35 * s.x + uHigh * tw * .45;
    vec3 col = mix(uColA, uColB, smoothstep(0., 1., s.y));
    col = mix(col, uColC, step(.93, s.w));
    vCol = col * bright;
    vA = fade * uOpacity * step(s.w, uKeep) * smoothstep(.4, 3., -mv.z) * (1. - .75 * smoothstep(40., 150., -mv.z));

    float size = uSize * (.45 + s.z) * (1. + uKick * 1.1 * s.x + uHigh * .5 * tw);
    gl_PointSize = clamp(size * uPointScale / max(-mv.z, .1), 1., 72.);
  }
`;
const FRAG = /* glsl */ `
  varying vec3 vCol; varying float vA;
  void main(){
    float d = length(gl_PointCoord - .5) * 2.;
    if (d > 1.) discard;
    float a = exp(-d * d * 4.2);
    gl_FragColor = vec4(min(vCol * a, vec3(3.)), a * vA);
  }
`;

export interface ParticleOptions {
  count: number;
  size?: number;
  colorA?: THREE.Color;
  colorB?: THREE.Color;
  colorC?: THREE.Color;
  seed?: number;
}

export class ParticleSystem {
  readonly group = new THREE.Group();
  readonly uniforms: Record<string, THREE.IUniform>;
  private layers: THREE.Points[] = [];
  private geo: THREE.BufferGeometry;
  readonly maxCount: number;

  constructor(opts: ParticleOptions) {
    this.maxCount = opts.count;
    const r = rng(opts.seed ?? 1);
    const seed = new Float32Array(opts.count * 4);
    const pos = new Float32Array(opts.count * 3); // unused by the shader, required by three
    for (let i = 0; i < seed.length; i++) seed[i] = r();
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 4));
    this.geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);

    this.uniforms = {
      uTime: { value: 0 }, uLag: { value: 0 }, uSize: { value: opts.size ?? 0.12 },
      uBass: { value: 0 }, uKick: { value: 0 }, uRms: { value: 0 }, uHigh: { value: 0 },
      uBurstT: { value: 9 }, uSink: { value: 0 }, uOpacity: { value: 1 }, uPointScale: Shared.pointScale,
      uSpeed: { value: 30 }, uSpin: { value: 1 }, uRadius: { value: 60 }, uTunnelR: { value: 14 },
      uTunnelLen: { value: 120 }, uTwist: { value: 3 }, uBurstR: { value: 60 },
      uMix: { value: new THREE.Vector4(1, 0, 0, 0) },
      uColA: { value: (opts.colorA ?? new THREE.Color('#00f0ff')).clone() },
      uColB: { value: (opts.colorB ?? new THREE.Color('#0a46ff')).clone() },
      uColC: { value: (opts.colorC ?? new THREE.Color('#9b30ff')).clone() },
      uOrigin: { value: new THREE.Vector3() },
      uKeep: { value: 1 },
    };
    // Layer 0 is the live particle cloud; layers 1..3 are motion-trail ghosts.
    for (let i = 0; i < 4; i++) {
      const mat = new THREE.ShaderMaterial({
        vertexShader: VERT,
        fragmentShader: FRAG,
        uniforms: i === 0 ? this.uniforms : { ...this.uniforms, uLag: { value: i * 0.045 }, uOpacity: { value: 0.5 / i } },
        transparent: true,
        depthWrite: false,
        depthTest: false,
        blending: THREE.AdditiveBlending,
      });
      const pts = new THREE.Points(this.geo, mat);
      pts.frustumCulled = false;
      pts.visible = i === 0;
      this.layers.push(pts);
      this.group.add(pts);
    }
  }

  /** Sets how many particles draw (quality-dependent) and how many trail ghosts. */
  setDensity(fraction: number, trails: number) {
    const n = Math.floor(this.maxCount * Math.min(1, fraction));
    this.layers.forEach((l, i) => {
      this.geo.setDrawRange(0, n);
      l.visible = i === 0 || i <= trails;
    });
    this.uniforms.uKeep.value = 1;
  }

  /** Feed music state. `opacity` lets scenes fade the whole field. */
  update(f: FrameState, opacity = 1) {
    const u = this.uniforms;
    u.uTime.value = f.t;
    u.uBass.value = f.bassS;
    u.uKick.value = f.kick;
    u.uRms.value = f.rms;
    u.uHigh.value = f.high;
    u.uBurstT.value = f.sinceDownbeat;
    // trail layers hold their own uOpacity; scale by the live one
    this.layers.forEach((l, i) => {
      const m = l.material as THREE.ShaderMaterial;
      m.uniforms.uOpacity.value = (i === 0 ? 1 : 0.5 / i) * opacity;
    });
  }

  setMix(dust: number, tunnel: number, burst: number) {
    (this.uniforms.uMix.value as THREE.Vector4).set(dust, tunnel, burst, 0);
  }

  dispose() {
    this.geo.dispose();
    this.layers.forEach((l) => (l.material as THREE.Material).dispose());
  }
}
